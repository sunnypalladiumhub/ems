#
# TABLE STRUCTURE FOR: tblactivity_log
#

DROP TABLE IF EXISTS `tblactivity_log`;

CREATE TABLE `tblactivity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (1, 'New Role Added [ID: 2.Management]', '2019-09-17 16:35:12', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (2, 'Staff Profile Updated [Staff: Norman Naidoo]', '2019-09-17 16:55:42', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (3, 'New Staff Member Added [ID: 2, Clint Brink]', '2019-09-17 17:01:41', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (4, 'New Department Added [Public Utility, ID: 1]', '2019-09-17 20:17:09', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (5, 'New Department Added [Private Utility, ID: 2]', '2019-09-17 20:17:24', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (6, 'Department Deleted [ID: 2]', '2019-09-17 20:18:14', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (7, 'Department Deleted [ID: 1]', '2019-09-17 20:18:24', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (8, 'New Customer Group Created [ID:1, Name:Public Utility]', '2019-09-17 20:18:49', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (9, 'New Customer Group Created [ID:2, Name:Private Utility]', '2019-09-17 20:18:59', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (10, 'New Customer Group Created [ID:3, Name:Vendor/Retailer]', '2019-09-17 20:23:41', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (11, 'New Customer Group Created [ID:4, Name:3rd Party]', '2019-09-17 20:23:56', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (12, 'New Customer Group Created [ID:5, Name:Body Corporate]', '2019-09-17 20:24:21', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (13, 'New Customer Group Created [ID:6, Name:End User]', '2019-09-17 20:24:52', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (14, 'New Tax Added [ID: 1, ZAR]', '2019-09-17 20:36:36', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (15, 'New Currency Added [ID: ZAR]', '2019-09-17 20:37:04', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (16, 'Currency Deleted [1]', '2019-09-17 20:37:37', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (17, 'Currency Deleted [2]', '2019-09-17 20:37:57', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (18, 'New Department Added [Networks, ID: 3]', '2019-09-17 20:58:11', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (19, 'New Department Added [Road Safety, ID: 4]', '2019-09-17 20:58:28', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (20, 'New Department Added [PayCity, ID: 5]', '2019-09-17 20:58:36', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (21, 'New Ticket Service Added [ID: 1.System Testing]', '2019-09-17 21:00:46', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (22, 'New Predefined Reply Added [ID: 1, Thank you for contacting support]', '2019-09-17 21:04:53', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (23, 'New Ticket Created [ID: 1]', '2019-09-17 21:05:04', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (24, 'New Task Added [ID:1, Name: #1 - The Very first ticket on the EMS System]', '2019-09-17 21:10:08', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (25, 'New Custom Field Added [Meter Number]', '2019-09-17 21:13:22', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (26, 'Ticket Updated [ID: 1]', '2019-09-17 21:14:24', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (27, 'Custom Field Updated [Meter Number]', '2019-09-17 21:15:35', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (28, 'Predefined Reply Updated [ID: 1, Thank you for contacting support]', '2019-09-17 21:21:54', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (29, 'Custom Field Updated [Meter Number]', '2019-09-17 21:23:10', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (30, 'New Ticket Reply [ReplyID: 1]', '2019-09-17 21:24:29', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (31, 'New Ticket Reply [ReplyID: 2]', '2019-09-17 21:25:24', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (32, 'Ticket Updated [ID: 1]', '2019-09-17 21:26:58', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (33, 'New Ticket Created [ID: 2]', '2019-09-17 21:39:33', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (34, 'Ticket Deleted [ID: 2]', '2019-09-17 21:41:37', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (35, 'Ticket Service Updated [ID: 1 Name: Vending]', '2019-09-17 21:42:14', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (36, 'New Ticket Service Added [ID: 2.Token]', '2019-09-17 21:42:23', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (37, 'New Ticket Service Added [ID: 3.Faulty meter]', '2019-09-17 21:43:46', 'Norman Naidoo');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (38, 'Ticket Deleted [ID: 1]', '2019-09-17 21:53:12', 'Norman Naidoo');


#
# TABLE STRUCTURE FOR: tblannouncements
#

DROP TABLE IF EXISTS `tblannouncements`;

CREATE TABLE `tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` text,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblclients
#

DROP TABLE IF EXISTS `tblclients`;

CREATE TABLE `tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(191) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT '0',
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT '0',
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT '0',
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT '0',
  `show_primary_contact` int(11) NOT NULL DEFAULT '0',
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT '1',
  `addedfrom` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblconsent_purposes
#

DROP TABLE IF EXISTS `tblconsent_purposes`;

CREATE TABLE `tblconsent_purposes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblconsents
#

DROP TABLE IF EXISTS `tblconsents`;

CREATE TABLE `tblconsents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `lead_id` int(11) NOT NULL DEFAULT '0',
  `description` text,
  `opt_in_purpose_description` text,
  `purpose_id` int(11) NOT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontact_permissions
#

DROP TABLE IF EXISTS `tblcontact_permissions`;

CREATE TABLE `tblcontact_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontacts
#

DROP TABLE IF EXISTS `tblcontacts`;

CREATE TABLE `tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT '1',
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT '1',
  `estimate_emails` tinyint(1) NOT NULL DEFAULT '1',
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT '1',
  `contract_emails` tinyint(1) NOT NULL DEFAULT '1',
  `task_emails` tinyint(1) NOT NULL DEFAULT '1',
  `project_emails` tinyint(1) NOT NULL DEFAULT '1',
  `ticket_emails` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontract_comments
#

DROP TABLE IF EXISTS `tblcontract_comments`;

CREATE TABLE `tblcontract_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext,
  `contract_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontract_renewals
#

DROP TABLE IF EXISTS `tblcontract_renewals`;

CREATE TABLE `tblcontract_renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT '0',
  `is_on_old_expiry_notified` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontracts
#

DROP TABLE IF EXISTS `tblcontracts`;

CREATE TABLE `tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `description` text,
  `subject` varchar(191) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT '0',
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT '0',
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT '0',
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT '0',
  `signature` varchar(40) DEFAULT NULL,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontracts_types
#

DROP TABLE IF EXISTS `tblcontracts_types`;

CREATE TABLE `tblcontracts_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcountries
#

DROP TABLE IF EXISTS `tblcountries`;

CREATE TABLE `tblcountries` (
  `country_id` int(5) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8;

INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (1, 'AF', 'Afghanistan', 'Islamic Republic of Afghanistan', 'AFG', '004', 'yes', '93', '.af');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (2, 'AX', 'Aland Islands', '&Aring;land Islands', 'ALA', '248', 'no', '358', '.ax');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (3, 'AL', 'Albania', 'Republic of Albania', 'ALB', '008', 'yes', '355', '.al');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (4, 'DZ', 'Algeria', 'People\'s Democratic Republic of Algeria', 'DZA', '012', 'yes', '213', '.dz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (5, 'AS', 'American Samoa', 'American Samoa', 'ASM', '016', 'no', '1+684', '.as');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (6, 'AD', 'Andorra', 'Principality of Andorra', 'AND', '020', 'yes', '376', '.ad');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (7, 'AO', 'Angola', 'Republic of Angola', 'AGO', '024', 'yes', '244', '.ao');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (8, 'AI', 'Anguilla', 'Anguilla', 'AIA', '660', 'no', '1+264', '.ai');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (9, 'AQ', 'Antarctica', 'Antarctica', 'ATA', '010', 'no', '672', '.aq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (10, 'AG', 'Antigua and Barbuda', 'Antigua and Barbuda', 'ATG', '028', 'yes', '1+268', '.ag');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (11, 'AR', 'Argentina', 'Argentine Republic', 'ARG', '032', 'yes', '54', '.ar');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (12, 'AM', 'Armenia', 'Republic of Armenia', 'ARM', '051', 'yes', '374', '.am');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (13, 'AW', 'Aruba', 'Aruba', 'ABW', '533', 'no', '297', '.aw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (14, 'AU', 'Australia', 'Commonwealth of Australia', 'AUS', '036', 'yes', '61', '.au');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (15, 'AT', 'Austria', 'Republic of Austria', 'AUT', '040', 'yes', '43', '.at');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (16, 'AZ', 'Azerbaijan', 'Republic of Azerbaijan', 'AZE', '031', 'yes', '994', '.az');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (17, 'BS', 'Bahamas', 'Commonwealth of The Bahamas', 'BHS', '044', 'yes', '1+242', '.bs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (18, 'BH', 'Bahrain', 'Kingdom of Bahrain', 'BHR', '048', 'yes', '973', '.bh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (19, 'BD', 'Bangladesh', 'People\'s Republic of Bangladesh', 'BGD', '050', 'yes', '880', '.bd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (20, 'BB', 'Barbados', 'Barbados', 'BRB', '052', 'yes', '1+246', '.bb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (21, 'BY', 'Belarus', 'Republic of Belarus', 'BLR', '112', 'yes', '375', '.by');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (22, 'BE', 'Belgium', 'Kingdom of Belgium', 'BEL', '056', 'yes', '32', '.be');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (23, 'BZ', 'Belize', 'Belize', 'BLZ', '084', 'yes', '501', '.bz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (24, 'BJ', 'Benin', 'Republic of Benin', 'BEN', '204', 'yes', '229', '.bj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (25, 'BM', 'Bermuda', 'Bermuda Islands', 'BMU', '060', 'no', '1+441', '.bm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (26, 'BT', 'Bhutan', 'Kingdom of Bhutan', 'BTN', '064', 'yes', '975', '.bt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (27, 'BO', 'Bolivia', 'Plurinational State of Bolivia', 'BOL', '068', 'yes', '591', '.bo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (28, 'BQ', 'Bonaire, Sint Eustatius and Saba', 'Bonaire, Sint Eustatius and Saba', 'BES', '535', 'no', '599', '.bq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (29, 'BA', 'Bosnia and Herzegovina', 'Bosnia and Herzegovina', 'BIH', '070', 'yes', '387', '.ba');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (30, 'BW', 'Botswana', 'Republic of Botswana', 'BWA', '072', 'yes', '267', '.bw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (31, 'BV', 'Bouvet Island', 'Bouvet Island', 'BVT', '074', 'no', 'NONE', '.bv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (32, 'BR', 'Brazil', 'Federative Republic of Brazil', 'BRA', '076', 'yes', '55', '.br');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (33, 'IO', 'British Indian Ocean Territory', 'British Indian Ocean Territory', 'IOT', '086', 'no', '246', '.io');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (34, 'BN', 'Brunei', 'Brunei Darussalam', 'BRN', '096', 'yes', '673', '.bn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (35, 'BG', 'Bulgaria', 'Republic of Bulgaria', 'BGR', '100', 'yes', '359', '.bg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (36, 'BF', 'Burkina Faso', 'Burkina Faso', 'BFA', '854', 'yes', '226', '.bf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (37, 'BI', 'Burundi', 'Republic of Burundi', 'BDI', '108', 'yes', '257', '.bi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (38, 'KH', 'Cambodia', 'Kingdom of Cambodia', 'KHM', '116', 'yes', '855', '.kh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (39, 'CM', 'Cameroon', 'Republic of Cameroon', 'CMR', '120', 'yes', '237', '.cm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (40, 'CA', 'Canada', 'Canada', 'CAN', '124', 'yes', '1', '.ca');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (41, 'CV', 'Cape Verde', 'Republic of Cape Verde', 'CPV', '132', 'yes', '238', '.cv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (42, 'KY', 'Cayman Islands', 'The Cayman Islands', 'CYM', '136', 'no', '1+345', '.ky');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (43, 'CF', 'Central African Republic', 'Central African Republic', 'CAF', '140', 'yes', '236', '.cf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (44, 'TD', 'Chad', 'Republic of Chad', 'TCD', '148', 'yes', '235', '.td');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (45, 'CL', 'Chile', 'Republic of Chile', 'CHL', '152', 'yes', '56', '.cl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (46, 'CN', 'China', 'People\'s Republic of China', 'CHN', '156', 'yes', '86', '.cn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (47, 'CX', 'Christmas Island', 'Christmas Island', 'CXR', '162', 'no', '61', '.cx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (48, 'CC', 'Cocos (Keeling) Islands', 'Cocos (Keeling) Islands', 'CCK', '166', 'no', '61', '.cc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (49, 'CO', 'Colombia', 'Republic of Colombia', 'COL', '170', 'yes', '57', '.co');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (50, 'KM', 'Comoros', 'Union of the Comoros', 'COM', '174', 'yes', '269', '.km');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (51, 'CG', 'Congo', 'Republic of the Congo', 'COG', '178', 'yes', '242', '.cg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (52, 'CK', 'Cook Islands', 'Cook Islands', 'COK', '184', 'some', '682', '.ck');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (53, 'CR', 'Costa Rica', 'Republic of Costa Rica', 'CRI', '188', 'yes', '506', '.cr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (54, 'CI', 'Cote d\'ivoire (Ivory Coast)', 'Republic of C&ocirc;te D\'Ivoire (Ivory Coast)', 'CIV', '384', 'yes', '225', '.ci');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (55, 'HR', 'Croatia', 'Republic of Croatia', 'HRV', '191', 'yes', '385', '.hr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (56, 'CU', 'Cuba', 'Republic of Cuba', 'CUB', '192', 'yes', '53', '.cu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (57, 'CW', 'Curacao', 'Cura&ccedil;ao', 'CUW', '531', 'no', '599', '.cw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (58, 'CY', 'Cyprus', 'Republic of Cyprus', 'CYP', '196', 'yes', '357', '.cy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (59, 'CZ', 'Czech Republic', 'Czech Republic', 'CZE', '203', 'yes', '420', '.cz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (60, 'CD', 'Democratic Republic of the Congo', 'Democratic Republic of the Congo', 'COD', '180', 'yes', '243', '.cd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (61, 'DK', 'Denmark', 'Kingdom of Denmark', 'DNK', '208', 'yes', '45', '.dk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (62, 'DJ', 'Djibouti', 'Republic of Djibouti', 'DJI', '262', 'yes', '253', '.dj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (63, 'DM', 'Dominica', 'Commonwealth of Dominica', 'DMA', '212', 'yes', '1+767', '.dm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (64, 'DO', 'Dominican Republic', 'Dominican Republic', 'DOM', '214', 'yes', '1+809, 8', '.do');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (65, 'EC', 'Ecuador', 'Republic of Ecuador', 'ECU', '218', 'yes', '593', '.ec');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (66, 'EG', 'Egypt', 'Arab Republic of Egypt', 'EGY', '818', 'yes', '20', '.eg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (67, 'SV', 'El Salvador', 'Republic of El Salvador', 'SLV', '222', 'yes', '503', '.sv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (68, 'GQ', 'Equatorial Guinea', 'Republic of Equatorial Guinea', 'GNQ', '226', 'yes', '240', '.gq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (69, 'ER', 'Eritrea', 'State of Eritrea', 'ERI', '232', 'yes', '291', '.er');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (70, 'EE', 'Estonia', 'Republic of Estonia', 'EST', '233', 'yes', '372', '.ee');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (71, 'ET', 'Ethiopia', 'Federal Democratic Republic of Ethiopia', 'ETH', '231', 'yes', '251', '.et');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (72, 'FK', 'Falkland Islands (Malvinas)', 'The Falkland Islands (Malvinas)', 'FLK', '238', 'no', '500', '.fk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (73, 'FO', 'Faroe Islands', 'The Faroe Islands', 'FRO', '234', 'no', '298', '.fo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (74, 'FJ', 'Fiji', 'Republic of Fiji', 'FJI', '242', 'yes', '679', '.fj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (75, 'FI', 'Finland', 'Republic of Finland', 'FIN', '246', 'yes', '358', '.fi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (76, 'FR', 'France', 'French Republic', 'FRA', '250', 'yes', '33', '.fr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (77, 'GF', 'French Guiana', 'French Guiana', 'GUF', '254', 'no', '594', '.gf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (78, 'PF', 'French Polynesia', 'French Polynesia', 'PYF', '258', 'no', '689', '.pf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (79, 'TF', 'French Southern Territories', 'French Southern Territories', 'ATF', '260', 'no', NULL, '.tf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (80, 'GA', 'Gabon', 'Gabonese Republic', 'GAB', '266', 'yes', '241', '.ga');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (81, 'GM', 'Gambia', 'Republic of The Gambia', 'GMB', '270', 'yes', '220', '.gm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (82, 'GE', 'Georgia', 'Georgia', 'GEO', '268', 'yes', '995', '.ge');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (83, 'DE', 'Germany', 'Federal Republic of Germany', 'DEU', '276', 'yes', '49', '.de');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (84, 'GH', 'Ghana', 'Republic of Ghana', 'GHA', '288', 'yes', '233', '.gh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (85, 'GI', 'Gibraltar', 'Gibraltar', 'GIB', '292', 'no', '350', '.gi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (86, 'GR', 'Greece', 'Hellenic Republic', 'GRC', '300', 'yes', '30', '.gr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (87, 'GL', 'Greenland', 'Greenland', 'GRL', '304', 'no', '299', '.gl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (88, 'GD', 'Grenada', 'Grenada', 'GRD', '308', 'yes', '1+473', '.gd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (89, 'GP', 'Guadaloupe', 'Guadeloupe', 'GLP', '312', 'no', '590', '.gp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (90, 'GU', 'Guam', 'Guam', 'GUM', '316', 'no', '1+671', '.gu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (91, 'GT', 'Guatemala', 'Republic of Guatemala', 'GTM', '320', 'yes', '502', '.gt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (92, 'GG', 'Guernsey', 'Guernsey', 'GGY', '831', 'no', '44', '.gg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (93, 'GN', 'Guinea', 'Republic of Guinea', 'GIN', '324', 'yes', '224', '.gn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (94, 'GW', 'Guinea-Bissau', 'Republic of Guinea-Bissau', 'GNB', '624', 'yes', '245', '.gw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (95, 'GY', 'Guyana', 'Co-operative Republic of Guyana', 'GUY', '328', 'yes', '592', '.gy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (96, 'HT', 'Haiti', 'Republic of Haiti', 'HTI', '332', 'yes', '509', '.ht');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (97, 'HM', 'Heard Island and McDonald Islands', 'Heard Island and McDonald Islands', 'HMD', '334', 'no', 'NONE', '.hm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (98, 'HN', 'Honduras', 'Republic of Honduras', 'HND', '340', 'yes', '504', '.hn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (99, 'HK', 'Hong Kong', 'Hong Kong', 'HKG', '344', 'no', '852', '.hk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (100, 'HU', 'Hungary', 'Hungary', 'HUN', '348', 'yes', '36', '.hu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (101, 'IS', 'Iceland', 'Republic of Iceland', 'ISL', '352', 'yes', '354', '.is');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (102, 'IN', 'India', 'Republic of India', 'IND', '356', 'yes', '91', '.in');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (103, 'ID', 'Indonesia', 'Republic of Indonesia', 'IDN', '360', 'yes', '62', '.id');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (104, 'IR', 'Iran', 'Islamic Republic of Iran', 'IRN', '364', 'yes', '98', '.ir');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (105, 'IQ', 'Iraq', 'Republic of Iraq', 'IRQ', '368', 'yes', '964', '.iq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (106, 'IE', 'Ireland', 'Ireland', 'IRL', '372', 'yes', '353', '.ie');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (107, 'IM', 'Isle of Man', 'Isle of Man', 'IMN', '833', 'no', '44', '.im');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (108, 'IL', 'Israel', 'State of Israel', 'ISR', '376', 'yes', '972', '.il');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (109, 'IT', 'Italy', 'Italian Republic', 'ITA', '380', 'yes', '39', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (110, 'JM', 'Jamaica', 'Jamaica', 'JAM', '388', 'yes', '1+876', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (111, 'JP', 'Japan', 'Japan', 'JPN', '392', 'yes', '81', '.jp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (112, 'JE', 'Jersey', 'The Bailiwick of Jersey', 'JEY', '832', 'no', '44', '.je');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (113, 'JO', 'Jordan', 'Hashemite Kingdom of Jordan', 'JOR', '400', 'yes', '962', '.jo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (114, 'KZ', 'Kazakhstan', 'Republic of Kazakhstan', 'KAZ', '398', 'yes', '7', '.kz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (115, 'KE', 'Kenya', 'Republic of Kenya', 'KEN', '404', 'yes', '254', '.ke');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (116, 'KI', 'Kiribati', 'Republic of Kiribati', 'KIR', '296', 'yes', '686', '.ki');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (117, 'XK', 'Kosovo', 'Republic of Kosovo', '---', '---', 'some', '381', '');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (118, 'KW', 'Kuwait', 'State of Kuwait', 'KWT', '414', 'yes', '965', '.kw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (119, 'KG', 'Kyrgyzstan', 'Kyrgyz Republic', 'KGZ', '417', 'yes', '996', '.kg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (120, 'LA', 'Laos', 'Lao People\'s Democratic Republic', 'LAO', '418', 'yes', '856', '.la');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (121, 'LV', 'Latvia', 'Republic of Latvia', 'LVA', '428', 'yes', '371', '.lv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (122, 'LB', 'Lebanon', 'Republic of Lebanon', 'LBN', '422', 'yes', '961', '.lb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (123, 'LS', 'Lesotho', 'Kingdom of Lesotho', 'LSO', '426', 'yes', '266', '.ls');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (124, 'LR', 'Liberia', 'Republic of Liberia', 'LBR', '430', 'yes', '231', '.lr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (125, 'LY', 'Libya', 'Libya', 'LBY', '434', 'yes', '218', '.ly');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (126, 'LI', 'Liechtenstein', 'Principality of Liechtenstein', 'LIE', '438', 'yes', '423', '.li');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (127, 'LT', 'Lithuania', 'Republic of Lithuania', 'LTU', '440', 'yes', '370', '.lt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (128, 'LU', 'Luxembourg', 'Grand Duchy of Luxembourg', 'LUX', '442', 'yes', '352', '.lu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (129, 'MO', 'Macao', 'The Macao Special Administrative Region', 'MAC', '446', 'no', '853', '.mo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (130, 'MK', 'North Macedonia', 'Republic of North Macedonia', 'MKD', '807', 'yes', '389', '.mk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (131, 'MG', 'Madagascar', 'Republic of Madagascar', 'MDG', '450', 'yes', '261', '.mg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (132, 'MW', 'Malawi', 'Republic of Malawi', 'MWI', '454', 'yes', '265', '.mw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (133, 'MY', 'Malaysia', 'Malaysia', 'MYS', '458', 'yes', '60', '.my');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (134, 'MV', 'Maldives', 'Republic of Maldives', 'MDV', '462', 'yes', '960', '.mv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (135, 'ML', 'Mali', 'Republic of Mali', 'MLI', '466', 'yes', '223', '.ml');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (136, 'MT', 'Malta', 'Republic of Malta', 'MLT', '470', 'yes', '356', '.mt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (137, 'MH', 'Marshall Islands', 'Republic of the Marshall Islands', 'MHL', '584', 'yes', '692', '.mh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (138, 'MQ', 'Martinique', 'Martinique', 'MTQ', '474', 'no', '596', '.mq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (139, 'MR', 'Mauritania', 'Islamic Republic of Mauritania', 'MRT', '478', 'yes', '222', '.mr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (140, 'MU', 'Mauritius', 'Republic of Mauritius', 'MUS', '480', 'yes', '230', '.mu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (141, 'YT', 'Mayotte', 'Mayotte', 'MYT', '175', 'no', '262', '.yt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (142, 'MX', 'Mexico', 'United Mexican States', 'MEX', '484', 'yes', '52', '.mx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (143, 'FM', 'Micronesia', 'Federated States of Micronesia', 'FSM', '583', 'yes', '691', '.fm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (144, 'MD', 'Moldava', 'Republic of Moldova', 'MDA', '498', 'yes', '373', '.md');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (145, 'MC', 'Monaco', 'Principality of Monaco', 'MCO', '492', 'yes', '377', '.mc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (146, 'MN', 'Mongolia', 'Mongolia', 'MNG', '496', 'yes', '976', '.mn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (147, 'ME', 'Montenegro', 'Montenegro', 'MNE', '499', 'yes', '382', '.me');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (148, 'MS', 'Montserrat', 'Montserrat', 'MSR', '500', 'no', '1+664', '.ms');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (149, 'MA', 'Morocco', 'Kingdom of Morocco', 'MAR', '504', 'yes', '212', '.ma');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (150, 'MZ', 'Mozambique', 'Republic of Mozambique', 'MOZ', '508', 'yes', '258', '.mz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (151, 'MM', 'Myanmar (Burma)', 'Republic of the Union of Myanmar', 'MMR', '104', 'yes', '95', '.mm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (152, 'NA', 'Namibia', 'Republic of Namibia', 'NAM', '516', 'yes', '264', '.na');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (153, 'NR', 'Nauru', 'Republic of Nauru', 'NRU', '520', 'yes', '674', '.nr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (154, 'NP', 'Nepal', 'Federal Democratic Republic of Nepal', 'NPL', '524', 'yes', '977', '.np');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (155, 'NL', 'Netherlands', 'Kingdom of the Netherlands', 'NLD', '528', 'yes', '31', '.nl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (156, 'NC', 'New Caledonia', 'New Caledonia', 'NCL', '540', 'no', '687', '.nc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (157, 'NZ', 'New Zealand', 'New Zealand', 'NZL', '554', 'yes', '64', '.nz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (158, 'NI', 'Nicaragua', 'Republic of Nicaragua', 'NIC', '558', 'yes', '505', '.ni');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (159, 'NE', 'Niger', 'Republic of Niger', 'NER', '562', 'yes', '227', '.ne');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (160, 'NG', 'Nigeria', 'Federal Republic of Nigeria', 'NGA', '566', 'yes', '234', '.ng');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (161, 'NU', 'Niue', 'Niue', 'NIU', '570', 'some', '683', '.nu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (162, 'NF', 'Norfolk Island', 'Norfolk Island', 'NFK', '574', 'no', '672', '.nf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (163, 'KP', 'North Korea', 'Democratic People\'s Republic of Korea', 'PRK', '408', 'yes', '850', '.kp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (164, 'MP', 'Northern Mariana Islands', 'Northern Mariana Islands', 'MNP', '580', 'no', '1+670', '.mp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (165, 'NO', 'Norway', 'Kingdom of Norway', 'NOR', '578', 'yes', '47', '.no');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (166, 'OM', 'Oman', 'Sultanate of Oman', 'OMN', '512', 'yes', '968', '.om');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (167, 'PK', 'Pakistan', 'Islamic Republic of Pakistan', 'PAK', '586', 'yes', '92', '.pk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (168, 'PW', 'Palau', 'Republic of Palau', 'PLW', '585', 'yes', '680', '.pw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (169, 'PS', 'Palestine', 'State of Palestine (or Occupied Palestinian Territory)', 'PSE', '275', 'some', '970', '.ps');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (170, 'PA', 'Panama', 'Republic of Panama', 'PAN', '591', 'yes', '507', '.pa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (171, 'PG', 'Papua New Guinea', 'Independent State of Papua New Guinea', 'PNG', '598', 'yes', '675', '.pg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (172, 'PY', 'Paraguay', 'Republic of Paraguay', 'PRY', '600', 'yes', '595', '.py');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (173, 'PE', 'Peru', 'Republic of Peru', 'PER', '604', 'yes', '51', '.pe');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (174, 'PH', 'Phillipines', 'Republic of the Philippines', 'PHL', '608', 'yes', '63', '.ph');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (175, 'PN', 'Pitcairn', 'Pitcairn', 'PCN', '612', 'no', 'NONE', '.pn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (176, 'PL', 'Poland', 'Republic of Poland', 'POL', '616', 'yes', '48', '.pl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (177, 'PT', 'Portugal', 'Portuguese Republic', 'PRT', '620', 'yes', '351', '.pt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (178, 'PR', 'Puerto Rico', 'Commonwealth of Puerto Rico', 'PRI', '630', 'no', '1+939', '.pr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (179, 'QA', 'Qatar', 'State of Qatar', 'QAT', '634', 'yes', '974', '.qa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (180, 'RE', 'Reunion', 'R&eacute;union', 'REU', '638', 'no', '262', '.re');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (181, 'RO', 'Romania', 'Romania', 'ROU', '642', 'yes', '40', '.ro');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (182, 'RU', 'Russia', 'Russian Federation', 'RUS', '643', 'yes', '7', '.ru');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (183, 'RW', 'Rwanda', 'Republic of Rwanda', 'RWA', '646', 'yes', '250', '.rw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (184, 'BL', 'Saint Barthelemy', 'Saint Barth&eacute;lemy', 'BLM', '652', 'no', '590', '.bl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (185, 'SH', 'Saint Helena', 'Saint Helena, Ascension and Tristan da Cunha', 'SHN', '654', 'no', '290', '.sh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (186, 'KN', 'Saint Kitts and Nevis', 'Federation of Saint Christopher and Nevis', 'KNA', '659', 'yes', '1+869', '.kn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (187, 'LC', 'Saint Lucia', 'Saint Lucia', 'LCA', '662', 'yes', '1+758', '.lc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (188, 'MF', 'Saint Martin', 'Saint Martin', 'MAF', '663', 'no', '590', '.mf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (189, 'PM', 'Saint Pierre and Miquelon', 'Saint Pierre and Miquelon', 'SPM', '666', 'no', '508', '.pm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (190, 'VC', 'Saint Vincent and the Grenadines', 'Saint Vincent and the Grenadines', 'VCT', '670', 'yes', '1+784', '.vc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (191, 'WS', 'Samoa', 'Independent State of Samoa', 'WSM', '882', 'yes', '685', '.ws');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (192, 'SM', 'San Marino', 'Republic of San Marino', 'SMR', '674', 'yes', '378', '.sm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (193, 'ST', 'Sao Tome and Principe', 'Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'STP', '678', 'yes', '239', '.st');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (194, 'SA', 'Saudi Arabia', 'Kingdom of Saudi Arabia', 'SAU', '682', 'yes', '966', '.sa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (195, 'SN', 'Senegal', 'Republic of Senegal', 'SEN', '686', 'yes', '221', '.sn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (196, 'RS', 'Serbia', 'Republic of Serbia', 'SRB', '688', 'yes', '381', '.rs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (197, 'SC', 'Seychelles', 'Republic of Seychelles', 'SYC', '690', 'yes', '248', '.sc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (198, 'SL', 'Sierra Leone', 'Republic of Sierra Leone', 'SLE', '694', 'yes', '232', '.sl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (199, 'SG', 'Singapore', 'Republic of Singapore', 'SGP', '702', 'yes', '65', '.sg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (200, 'SX', 'Sint Maarten', 'Sint Maarten', 'SXM', '534', 'no', '1+721', '.sx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (201, 'SK', 'Slovakia', 'Slovak Republic', 'SVK', '703', 'yes', '421', '.sk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (202, 'SI', 'Slovenia', 'Republic of Slovenia', 'SVN', '705', 'yes', '386', '.si');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (203, 'SB', 'Solomon Islands', 'Solomon Islands', 'SLB', '090', 'yes', '677', '.sb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (204, 'SO', 'Somalia', 'Somali Republic', 'SOM', '706', 'yes', '252', '.so');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (205, 'ZA', 'South Africa', 'Republic of South Africa', 'ZAF', '710', 'yes', '27', '.za');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (206, 'GS', 'South Georgia and the South Sandwich Islands', 'South Georgia and the South Sandwich Islands', 'SGS', '239', 'no', '500', '.gs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (207, 'KR', 'South Korea', 'Republic of Korea', 'KOR', '410', 'yes', '82', '.kr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (208, 'SS', 'South Sudan', 'Republic of South Sudan', 'SSD', '728', 'yes', '211', '.ss');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (209, 'ES', 'Spain', 'Kingdom of Spain', 'ESP', '724', 'yes', '34', '.es');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (210, 'LK', 'Sri Lanka', 'Democratic Socialist Republic of Sri Lanka', 'LKA', '144', 'yes', '94', '.lk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (211, 'SD', 'Sudan', 'Republic of the Sudan', 'SDN', '729', 'yes', '249', '.sd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (212, 'SR', 'Suriname', 'Republic of Suriname', 'SUR', '740', 'yes', '597', '.sr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (213, 'SJ', 'Svalbard and Jan Mayen', 'Svalbard and Jan Mayen', 'SJM', '744', 'no', '47', '.sj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (214, 'SZ', 'Swaziland', 'Kingdom of Swaziland', 'SWZ', '748', 'yes', '268', '.sz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (215, 'SE', 'Sweden', 'Kingdom of Sweden', 'SWE', '752', 'yes', '46', '.se');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (216, 'CH', 'Switzerland', 'Swiss Confederation', 'CHE', '756', 'yes', '41', '.ch');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (217, 'SY', 'Syria', 'Syrian Arab Republic', 'SYR', '760', 'yes', '963', '.sy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (218, 'TW', 'Taiwan', 'Republic of China (Taiwan)', 'TWN', '158', 'former', '886', '.tw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (219, 'TJ', 'Tajikistan', 'Republic of Tajikistan', 'TJK', '762', 'yes', '992', '.tj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (220, 'TZ', 'Tanzania', 'United Republic of Tanzania', 'TZA', '834', 'yes', '255', '.tz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (221, 'TH', 'Thailand', 'Kingdom of Thailand', 'THA', '764', 'yes', '66', '.th');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (222, 'TL', 'Timor-Leste (East Timor)', 'Democratic Republic of Timor-Leste', 'TLS', '626', 'yes', '670', '.tl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (223, 'TG', 'Togo', 'Togolese Republic', 'TGO', '768', 'yes', '228', '.tg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (224, 'TK', 'Tokelau', 'Tokelau', 'TKL', '772', 'no', '690', '.tk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (225, 'TO', 'Tonga', 'Kingdom of Tonga', 'TON', '776', 'yes', '676', '.to');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (226, 'TT', 'Trinidad and Tobago', 'Republic of Trinidad and Tobago', 'TTO', '780', 'yes', '1+868', '.tt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (227, 'TN', 'Tunisia', 'Republic of Tunisia', 'TUN', '788', 'yes', '216', '.tn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (228, 'TR', 'Turkey', 'Republic of Turkey', 'TUR', '792', 'yes', '90', '.tr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (229, 'TM', 'Turkmenistan', 'Turkmenistan', 'TKM', '795', 'yes', '993', '.tm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (230, 'TC', 'Turks and Caicos Islands', 'Turks and Caicos Islands', 'TCA', '796', 'no', '1+649', '.tc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (231, 'TV', 'Tuvalu', 'Tuvalu', 'TUV', '798', 'yes', '688', '.tv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (232, 'UG', 'Uganda', 'Republic of Uganda', 'UGA', '800', 'yes', '256', '.ug');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (233, 'UA', 'Ukraine', 'Ukraine', 'UKR', '804', 'yes', '380', '.ua');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (234, 'AE', 'United Arab Emirates', 'United Arab Emirates', 'ARE', '784', 'yes', '971', '.ae');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (235, 'GB', 'United Kingdom', 'United Kingdom of Great Britain and Nothern Ireland', 'GBR', '826', 'yes', '44', '.uk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (236, 'US', 'United States', 'United States of America', 'USA', '840', 'yes', '1', '.us');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (237, 'UM', 'United States Minor Outlying Islands', 'United States Minor Outlying Islands', 'UMI', '581', 'no', 'NONE', 'NONE');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (238, 'UY', 'Uruguay', 'Eastern Republic of Uruguay', 'URY', '858', 'yes', '598', '.uy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (239, 'UZ', 'Uzbekistan', 'Republic of Uzbekistan', 'UZB', '860', 'yes', '998', '.uz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (240, 'VU', 'Vanuatu', 'Republic of Vanuatu', 'VUT', '548', 'yes', '678', '.vu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (241, 'VA', 'Vatican City', 'State of the Vatican City', 'VAT', '336', 'no', '39', '.va');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (242, 'VE', 'Venezuela', 'Bolivarian Republic of Venezuela', 'VEN', '862', 'yes', '58', '.ve');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (243, 'VN', 'Vietnam', 'Socialist Republic of Vietnam', 'VNM', '704', 'yes', '84', '.vn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (244, 'VG', 'Virgin Islands, British', 'British Virgin Islands', 'VGB', '092', 'no', '1+284', '.vg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (245, 'VI', 'Virgin Islands, US', 'Virgin Islands of the United States', 'VIR', '850', 'no', '1+340', '.vi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (246, 'WF', 'Wallis and Futuna', 'Wallis and Futuna', 'WLF', '876', 'no', '681', '.wf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (247, 'EH', 'Western Sahara', 'Western Sahara', 'ESH', '732', 'no', '212', '.eh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (248, 'YE', 'Yemen', 'Republic of Yemen', 'YEM', '887', 'yes', '967', '.ye');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (249, 'ZM', 'Zambia', 'Republic of Zambia', 'ZMB', '894', 'yes', '260', '.zm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (250, 'ZW', 'Zimbabwe', 'Republic of Zimbabwe', 'ZWE', '716', 'yes', '263', '.zw');


#
# TABLE STRUCTURE FOR: tblcreditnote_refunds
#

DROP TABLE IF EXISTS `tblcreditnote_refunds`;

CREATE TABLE `tblcreditnote_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) NOT NULL,
  `note` text,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcreditnotes
#

DROP TABLE IF EXISTS `tblcreditnotes`;

CREATE TABLE `tblcreditnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '1',
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` text,
  `terms` text,
  `clientnote` text,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `discount_percent` decimal(15,2) DEFAULT '0.00',
  `discount_total` decimal(15,2) DEFAULT '0.00',
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcredits
#

DROP TABLE IF EXISTS `tblcredits`;

CREATE TABLE `tblcredits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcurrencies
#

DROP TABLE IF EXISTS `tblcurrencies`;

CREATE TABLE `tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `decimal_separator` varchar(5) DEFAULT NULL,
  `thousand_separator` varchar(5) DEFAULT NULL,
  `placement` varchar(10) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `decimal_separator`, `thousand_separator`, `placement`, `isdefault`) VALUES (3, 'R', 'ZAR', '.', ',', 'before', 1);


#
# TABLE STRUCTURE FOR: tblcustomer_admins
#

DROP TABLE IF EXISTS `tblcustomer_admins`;

CREATE TABLE `tblcustomer_admins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` text NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomer_groups
#

DROP TABLE IF EXISTS `tblcustomer_groups`;

CREATE TABLE `tblcustomer_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomers_groups
#

DROP TABLE IF EXISTS `tblcustomers_groups`;

CREATE TABLE `tblcustomers_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tblcustomers_groups` (`id`, `name`) VALUES (4, '3rd Party');
INSERT INTO `tblcustomers_groups` (`id`, `name`) VALUES (5, 'Body Corporate');
INSERT INTO `tblcustomers_groups` (`id`, `name`) VALUES (6, 'End User');
INSERT INTO `tblcustomers_groups` (`id`, `name`) VALUES (2, 'Private Utility');
INSERT INTO `tblcustomers_groups` (`id`, `name`) VALUES (1, 'Public Utility');
INSERT INTO `tblcustomers_groups` (`id`, `name`) VALUES (3, 'Vendor/Retailer');


#
# TABLE STRUCTURE FOR: tblcustomfields
#

DROP TABLE IF EXISTS `tblcustomfields`;

CREATE TABLE `tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(15) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL,
  `options` mediumtext,
  `display_inline` tinyint(1) NOT NULL DEFAULT '0',
  `field_order` int(11) DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '1',
  `show_on_pdf` int(11) NOT NULL DEFAULT '0',
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT '0',
  `only_admin` tinyint(1) NOT NULL DEFAULT '0',
  `show_on_table` tinyint(1) NOT NULL DEFAULT '0',
  `show_on_client_portal` int(11) NOT NULL DEFAULT '0',
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT '0',
  `bs_column` int(11) NOT NULL DEFAULT '12',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`) VALUES (1, 'tickets', 'Meter Number', 'tickets_meter_number', 0, 'number', '', 0, -3, 1, 0, 1, 0, 1, 1, 0, 6);


#
# TABLE STRUCTURE FOR: tblcustomfieldsvalues
#

DROP TABLE IF EXISTS `tblcustomfieldsvalues`;

CREATE TABLE `tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(15) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbldepartments
#

DROP TABLE IF EXISTS `tbldepartments`;

CREATE TABLE `tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT '0',
  `host` varchar(150) DEFAULT NULL,
  `password` mediumtext,
  `encryption` varchar(3) DEFAULT NULL,
  `delete_after_import` int(11) NOT NULL DEFAULT '0',
  `calendar_id` mediumtext,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbldepartments` (`departmentid`, `name`, `imap_username`, `email`, `email_from_header`, `host`, `password`, `encryption`, `delete_after_import`, `calendar_id`, `hidefromclient`) VALUES (3, 'Networks', 'norman@119next.com', '', 0, '', '', '', 0, NULL, 0);
INSERT INTO `tbldepartments` (`departmentid`, `name`, `imap_username`, `email`, `email_from_header`, `host`, `password`, `encryption`, `delete_after_import`, `calendar_id`, `hidefromclient`) VALUES (4, 'Road Safety', '', '', 0, '', '', '', 0, NULL, 0);
INSERT INTO `tbldepartments` (`departmentid`, `name`, `imap_username`, `email`, `email_from_header`, `host`, `password`, `encryption`, `delete_after_import`, `calendar_id`, `hidefromclient`) VALUES (5, 'PayCity', '', '', 0, '', '', '', 0, NULL, 0);


#
# TABLE STRUCTURE FOR: tbldismissed_announcements
#

DROP TABLE IF EXISTS `tbldismissed_announcements`;

CREATE TABLE `tbldismissed_announcements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblemaillists
#

DROP TABLE IF EXISTS `tblemaillists`;

CREATE TABLE `tblemaillists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  `creator` varchar(100) NOT NULL,
  `datecreated` datetime NOT NULL,
  PRIMARY KEY (`listid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblemailtemplates
#

DROP TABLE IF EXISTS `tblemailtemplates`;

CREATE TABLE `tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` mediumtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` mediumtext NOT NULL,
  `subject` mediumtext NOT NULL,
  `message` text NOT NULL,
  `fromname` mediumtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;

INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (1, 'client', 'new-client-created', 'english', 'New Contact Added/Registered (Welcome Email)', 'Welcome aboard', 'Dear {contact_firstname} {contact_lastname}<br /><br />Thank you for registering on the <strong>{companyname}</strong> CRM System.<br /><br />We just wanted to say welcome.<br /><br />Please contact us if you need any help.<br /><br />Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a><br /><br />Kind Regards, <br />{email_signature}<br /><br />(This is an automated email, so please don\'t reply to this email address)', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (2, 'invoice', 'invoice-send-to-client', 'english', 'Send Invoice to Customer', 'Invoice with number {invoice_number} created', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">We have prepared the following invoice for you: <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Invoice status</strong>: {invoice_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (3, 'ticket', 'new-ticket-opened-admin', 'english', 'New Ticket Opened (Opened by Staff, Sent to Customer)', 'New Support Ticket Opened', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department:</strong> {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}<br /><br /></a>Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (4, 'ticket', 'ticket-reply', 'english', 'Ticket Reply (Sent to Customer)', 'New Ticket Reply', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">You have a new ticket reply to ticket <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket Subject:</strong> {ticket_subject}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (5, 'ticket', 'ticket-autoresponse', 'english', 'New Ticket Opened - Autoresponse', 'New Support Ticket Opened', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span><br /> <br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /> <br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (6, 'invoice', 'invoice-payment-recorded', 'english', 'Invoice Payment Recorded (Sent to Customer)', 'Invoice Payment Recorded', '<span style=\"font-size: 12pt;\">Hello {contact_firstname}&nbsp;{contact_lastname}<br /><br /></span>Thank you for the payment. Find the payment details below:<br /><br />-------------------------------------------------<br /><br />Amount:&nbsp;<strong>{payment_total}<br /></strong>Date:&nbsp;<strong>{payment_date}</strong><br />Invoice number:&nbsp;<span style=\"font-size: 12pt;\"><strong># {invoice_number}<br /><br /></strong></span>-------------------------------------------------<br /><br />You can always view the invoice for this payment at the following link:&nbsp;<a href=\"{invoice_link}\"><span style=\"font-size: 12pt;\">{invoice_number}</span></a><br /><br />We are looking forward working with you.<br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (7, 'invoice', 'invoice-overdue-notice', 'english', 'Invoice Overdue Notice', 'Invoice Overdue Notice - {invoice_number}', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">This is an overdue notice for invoice <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">This invoice was due: {invoice_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (8, 'invoice', 'invoice-already-send', 'english', 'Invoice Already Sent to Customer', 'Invoice # {invoice_number} ', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">At your request, here is the invoice with number <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (9, 'ticket', 'new-ticket-created-staff', 'english', 'New Ticket Created (Opened by Customer, Sent to Staff Members)', 'New Ticket Created', '<span style=\"font-size: 12pt;\">A new support ticket has been opened.</span><br /> <br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /> <br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}<br /></a></span><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (10, 'estimate', 'estimate-send-to-client', 'english', 'Send Estimate to Customer', 'Estimate # {estimate_number} created', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Please find the attached estimate <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\"><strong>Estimate status:</strong> {estimate_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to your communication.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}<br /></span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (11, 'ticket', 'ticket-reply-to-admin', 'english', 'Ticket Reply (Sent to Staff)', 'New Support Ticket Reply', '<span style=\"font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /> <br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (12, 'estimate', 'estimate-already-send', 'english', 'Estimate Already Sent to Customer', 'Estimate # {estimate_number} ', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank you for your estimate request.</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (13, 'contract', 'contract-expiration', 'english', 'Contract Expiration Reminder (Sent to Customer Contacts)', 'Contract Expiration Reminder', '<span style=\"font-size: 12pt;\">Dear {client_company}</span><br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (14, 'tasks', 'task-assigned', 'english', 'New Task Assigned (Sent to Staff)', 'New Task Assigned to You - {task_name}', '<span style=\"font-size: 12pt;\">Dear {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\">You have been assigned to a new task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}<br /></span><strong>Start Date:</strong> {task_startdate}<br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {task_priority}<br /><br /></span><span style=\"font-size: 12pt;\"><span>You can view the task on the following link</span>: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (15, 'tasks', 'task-added-as-follower', 'english', 'Staff Member Added as Follower on Task (Sent to Staff)', 'You are added as follower on task - {task_name}', '<span style=\"font-size: 12pt;\">Hi {staff_firstname}<br /></span><br /><span style=\"font-size: 12pt;\">You have been added as follower on the following task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Start date:</strong> {task_startdate}</span><br /><br /><span>You can view the task on the following link</span><span>: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (16, 'tasks', 'task-commented', 'english', 'New Comment on Task (Sent to Staff)', 'New Comment on Task - {task_name}', 'Dear {staff_firstname}<br /><br />A comment has been made on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><strong>Comment:</strong> {task_comment}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (17, 'tasks', 'task-added-attachment', 'english', 'New Attachment(s) on Task (Sent to Staff)', 'New Attachment on Task - {task_name}', 'Hi {staff_firstname}<br /><br /><strong>{task_user_take_action}</strong> added an attachment on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (18, 'estimate', 'estimate-declined-to-staff', 'english', 'Estimate Declined (Sent to Staff)', 'Customer Declined Estimate', '<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (19, 'estimate', 'estimate-accepted-to-staff', 'english', 'Estimate Accepted (Sent to Staff)', 'Customer Accepted Estimate', '<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (20, 'proposals', 'proposal-client-accepted', 'english', 'Customer Action - Accepted (Sent to Staff)', 'Customer Accepted Proposal', '<div>Hi<br /> <br />Client <strong>{proposal_proposal_to}</strong> accepted the following proposal:<br /> <br /><strong>Number:</strong> {proposal_number}<br /><strong>Subject</strong>: {proposal_subject}<br /><strong>Total</strong>: {proposal_total}<br /> <br />View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (21, 'proposals', 'proposal-send-to-customer', 'english', 'Send Proposal to Customer', 'Proposal With Number {proposal_number} Created', 'Dear {proposal_proposal_to}<br /><br />Please find our attached proposal.<br /><br />This proposal is valid until: {proposal_open_till}<br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Please don\'t hesitate to comment online if you have any questions.<br /><br />We look forward to your communication.<br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (22, 'proposals', 'proposal-client-declined', 'english', 'Customer Action - Declined (Sent to Staff)', 'Client Declined Proposal', 'Hi<br /> <br />Customer <strong>{proposal_proposal_to}</strong> declined the proposal <strong>{proposal_subject}</strong><br /> <br />View the proposal on the following link <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (23, 'proposals', 'proposal-client-thank-you', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting proposal', 'Dear {proposal_proposal_to}<br /> <br />Thank for for accepting the proposal.<br /> <br />We look forward to doing business with you.<br /> <br />We will contact you as soon as possible<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (24, 'proposals', 'proposal-comment-to-client', 'english', 'New Comment Â (Sent to Customer/Lead)', 'New Proposal Comment', 'Dear {proposal_proposal_to}<br /> <br />A new comment has been made on the following proposal: <strong>{proposal_number}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (25, 'proposals', 'proposal-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Proposal Comment', 'Hi<br /> <br />A new comment has been made to the proposal <strong>{proposal_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (26, 'estimate', 'estimate-thank-you-to-customer', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting estimate', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank for for accepting the estimate.</span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to doing business with you.</span><br /> <br /><span style=\"font-size: 12pt;\">We will contact you as soon as possible.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (27, 'tasks', 'task-deadline-notification', 'english', 'Task Deadline Reminder - Sent to Assigned Members', 'Task Deadline Reminder', 'Hi {staff_firstname}&nbsp;{staff_lastname}<br /><br />This is an automated email from {companyname}.<br /><br />The task <strong>{task_name}</strong> deadline is on <strong>{task_duedate}</strong>. <br />This task is still not finished.<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (28, 'contract', 'send-contract', 'english', 'Send Contract to Customer', 'Contract - {contract_subject}', '<p><span style=\"font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the {contract_subject} attached.<br /><br />Description: {contract_description}<br /><br /></span><span style=\"font-size: 12pt;\">Looking forward to hear from you.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (29, 'invoice', 'invoice-payment-recorded-to-staff', 'english', 'Invoice Payment Recorded (Sent to Staff)', 'New Invoice Payment', '<span style=\"font-size: 12pt;\">Hi</span><br /><br /><span style=\"font-size: 12pt;\">Customer recorded payment for invoice <strong># {invoice_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (30, 'ticket', 'auto-close-ticket', 'english', 'Auto Close Ticket', 'Ticket Auto Closed', '<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Ticket {ticket_subject} has been auto close due to inactivity.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket #</strong>: <a href=\"{ticket_url}\">{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (31, 'project', 'new-project-discussion-created-to-staff', 'english', 'New Project Discussion (Sent to Project Members)', 'New Project Discussion Created - {project_name}', '<p>Hi {staff_firstname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (32, 'project', 'new-project-discussion-created-to-customer', 'english', 'New Project Discussion (Sent to Customer Contacts)', 'New Project Discussion Created - {project_name}', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (33, 'project', 'new-project-file-uploaded-to-customer', 'english', 'New Project File(s) Uploaded (Sent to Customer Contacts)', 'New Project File(s) Uploaded - {project_name}', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project file is uploaded on <strong>{project_name}</strong> from <strong>{file_creator}</strong><br /><br />You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br /><br />To view the file in our CRM you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (34, 'project', 'new-project-file-uploaded-to-staff', 'english', 'New Project File(s) Uploaded (Sent to Project Members)', 'New Project File(s) Uploaded - {project_name}', '<p>Hello&nbsp;{staff_firstname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;<strong>{project_name}</strong> from&nbsp;<strong>{file_creator}</strong></p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}<br /></a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (35, 'project', 'new-project-discussion-comment-to-customer', 'english', 'New Discussion Comment  (Sent to Customer Contacts)', 'New Discussion Comment', '<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Discussion subject:</strong> {discussion_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Comment</strong>: {discussion_comment}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (36, 'project', 'new-project-discussion-comment-to-staff', 'english', 'New Discussion Comment (Sent to Project Members)', 'New Discussion Comment', '<p>Hi {staff_firstname}<br /><br />New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong><br /><br /><strong>Discussion subject:</strong> {discussion_subject}<br /><strong>Comment:</strong> {discussion_comment}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (37, 'project', 'staff-added-as-project-member', 'english', 'Staff Added as Project Member', 'New project assigned to you', '<p>Hi {staff_firstname}<br /><br />New project has been assigned to you.<br /><br />You can view the project on the following link <a href=\"{project_link}\">{project_name}</a><br /><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (38, 'estimate', 'estimate-expiry-reminder', 'english', 'Estimate Expiration Reminder', 'Estimate Expiration Reminder', '<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">The estimate with <strong># {estimate_number}</strong> will expire on <strong>{estimate_expirydate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (39, 'proposals', 'proposal-expiry-reminder', 'english', 'Proposal Expiration Reminder', 'Proposal Expiration Reminder', '<p>Hello {proposal_proposal_to}<br /><br />The proposal {proposal_number}&nbsp;will expire on <strong>{proposal_open_till}</strong><br /><br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (40, 'staff', 'new-staff-created', 'english', 'New Staff Created (Welcome Email)', 'You are added as staff member', 'Hi {staff_firstname}<br /><br />You are added as member on our CRM.<br /><br />Please use the following logic credentials:<br /><br /><strong>Email:</strong> {staff_email}<br /><strong>Password:</strong> {password}<br /><br />Click <a href=\"{admin_url}\">here </a>to login in the dashboard.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (41, 'client', 'contact-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (42, 'client', 'contact-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<strong><span style=\"font-size: 14pt;\">You have changed your password.</span><br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br /><br />If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (43, 'client', 'contact-set-password', 'english', 'Set New Password', 'Set new password on {companyname} ', '<h2><span style=\"font-size: 14pt;\">Setup your new password on {companyname}</span></h2>\r\nPlease use the following link to set up your new password:<br /><br /><a href=\"{set_password_url}\">Set new password</a><br /><br />Keep it in your records so you don\'t forget it.<br /><br />Please set your new password in <strong>48 hours</strong>. After that, you won\'t be able to set your password because this link will expire.<br /><br />You can login at: <a href=\"{crm_url}\">{crm_url}</a><br />Your email address for login: {contact_email}<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (44, 'staff', 'staff-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2><span style=\"font-size: 14pt;\">Create a new password</span></h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a <strong>{companyname}</strong>&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (45, 'staff', 'staff-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<span style=\"font-size: 14pt;\"><strong>You have changed your password.<br /></strong></span><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /><br /> If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (46, 'project', 'assigned-to-project', 'english', 'New Project Created (Sent to Customer Contacts)', 'New Project Created', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project is assigned to your company.<br /><br /><strong>Project Name:</strong>&nbsp;{project_name}<br /><strong>Project Start Date:</strong>&nbsp;{project_start_date}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.<br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (47, 'tasks', 'task-added-attachment-to-contacts', 'english', 'New Attachment(s) on Task (Sent to Customer Contacts)', 'New Attachment on Task - {task_name}', '<span>Hi {contact_firstname} {contact_lastname}</span><br /><br /><strong>{task_user_take_action}</strong><span> added an attachment on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (48, 'tasks', 'task-commented-to-contacts', 'english', 'New Comment on Task (Sent to Customer Contacts)', 'New Comment on Task - {task_name}', '<span>Dear {contact_firstname} {contact_lastname}</span><br /><br /><span>A comment has been made on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><strong>Comment:</strong><span> {task_comment}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (49, 'leads', 'new-lead-assigned', 'english', 'New Lead Assigned to Staff Member', 'New lead assigned to you', '<p>Hello {lead_assigned}<br /><br />New lead is assigned to you.<br /><br /><strong>Lead Name:</strong>&nbsp;{lead_name}<br /><strong>Lead Email:</strong>&nbsp;{lead_email}<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (50, 'client', 'client-statement', 'english', 'Statement - Account Summary', 'Account Statement from {statement_from} to {statement_to}', 'Dear {contact_firstname} {contact_lastname}, <br /><br />Its been a great experience working with you.<br /><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br /><br />For your information your account balance due is total:&nbsp;{statement_balance_due}<br /><br />Please contact us if you need more information.<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (51, 'ticket', 'ticket-assigned-to-admin', 'english', 'New Ticket Assigned (Sent to Staff)', 'New support ticket has been assigned to you', '<p><span style=\"font-size: 12pt;\">Hi</span></p>\r\n<p><span style=\"font-size: 12pt;\">A new support ticket&nbsp;has been assigned to you.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (52, 'client', 'new-client-registered-to-admin', 'english', 'New Customer Registration (Sent to admins)', 'New Customer Registration', 'Hello.<br /><br />New customer registration on your customer portal:<br /><br /><strong>Firstname:</strong>&nbsp;{contact_firstname}<br /><strong>Lastname:</strong>&nbsp;{contact_lastname}<br /><strong>Company:</strong>&nbsp;{client_company}<br /><strong>Email:</strong>&nbsp;{contact_email}<br /><br />Best Regards', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (53, 'leads', 'new-web-to-lead-form-submitted', 'english', 'Web to lead form submitted - Sent to lead', '{lead_name} - We Received Your Request', 'Hello {lead_name}.<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 0, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (54, 'staff', 'two-factor-authentication', 'english', 'Two Factor Authentication', 'Confirm Your Login', '<p>Hi {staff_firstname}</p>\r\n<p style=\"text-align: left;\">You received this email because you have enabled two factor authentication in your account.<br />Use the following code to confirm your login:</p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 18pt;\"><strong>{two_factor_auth_code}<br /><br /></strong><span style=\"font-size: 12pt;\">{email_signature}</span><strong><br /><br /><br /><br /></strong></span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (55, 'project', 'project-finished-to-customer', 'english', 'Project Marked as Finished (Sent to Customer Contacts)', 'Project Marked as Finished', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>You are receiving this email because project&nbsp;<strong>{project_name}</strong> has been marked as finished. This project is assigned under your company and we just wanted to keep you up to date.<br /><br />You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>If you have any questions don\'t hesitate to contact us.<br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (56, 'credit_note', 'credit-note-send-to-client', 'english', 'Send Credit Note To Email', 'Credit Note With Number #{credit_note_number} Created', 'Dear&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have attached the credit note with number <strong>#{credit_note_number} </strong>for your reference.<br /><br /><strong>Date:</strong>&nbsp;{credit_note_date}<br /><strong>Total Amount:</strong>&nbsp;{credit_note_total}<br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (57, 'tasks', 'task-status-change-to-staff', 'english', 'Task Status Changed (Sent to Staff)', 'Task Status Changed', '<span style=\"font-size: 12pt;\">Hi {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (58, 'tasks', 'task-status-change-to-contacts', 'english', 'Task Status Changed (Sent to Customer Contacts)', 'Task Status Changed', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (59, 'staff', 'reminder-email-staff', 'english', 'Staff Reminder Email', 'You Have a New Reminder!', '<p>Hello&nbsp;{staff_firstname}<br /><br /><strong>You have a new reminder&nbsp;linked to&nbsp;{staff_reminder_relation_name}!<br /><br />Reminder description:</strong><br />{staff_reminder_description}<br /><br />Click <a href=\"{staff_reminder_relation_link}\">here</a> to view&nbsp;<a href=\"{staff_reminder_relation_link}\">{staff_reminder_relation_name}</a><br /><br />Best Regards<br /><br /></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (60, 'contract', 'contract-comment-to-client', 'english', 'New Comment Â (Sent to Customer Contacts)', 'New Contract Comment', 'Dear {contact_firstname} {contact_lastname}<br /> <br />A new comment has been made on the following contract: <strong>{contract_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a><br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (61, 'contract', 'contract-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Contract Comment', 'Hi {staff_firstname}<br /><br />A new comment has been made to the contract&nbsp;<strong>{contract_subject}</strong><br /><br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (62, 'subscriptions', 'send-subscription', 'english', 'Send Subscription to Customer', 'Subscription Created', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have prepared the subscription&nbsp;<strong>{subscription_name}</strong> for your company.<br /><br />Click <a href=\"{subscription_link}\">here</a> to review the subscription and subscribe.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (63, 'subscriptions', 'subscription-payment-failed', 'english', 'Subscription Payment Failed', 'Your most recent invoice payment failed', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br br=\"\" />Unfortunately, your most recent invoice payment for&nbsp;<strong>{subscription_name}</strong> was declined.<br /><br />This could be due to a change in your card number, your card expiring,<br />cancellation of your credit card, or the card issuer not recognizing the<br />payment and therefore taking action to prevent it.<br /><br />Please update your payment information as soon as possible by logging in here:<br /><a href=\"{crm_url}/login\">{crm_url}/login</a><br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (64, 'subscriptions', 'subscription-canceled', 'english', 'Subscription Canceled (Sent to customer primary contact)', 'Your subscription has been canceled', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />Your subscription&nbsp;<strong>{subscription_name} </strong>has been canceled, if you have any questions don\'t hesitate to contact us.<br /><br />It was a pleasure doing business with you.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (65, 'subscriptions', 'subscription-payment-succeeded', 'english', 'Subscription Payment Succeeded (Sent to customer primary contact)', 'Subscription  Payment Receipt - {subscription_name}', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />This email is to let you know that we received your payment for subscription&nbsp;<strong>{subscription_name}&nbsp;</strong>of&nbsp;<strong><span>{payment_total}<br /><br /></span></strong>The invoice associated with it is now with status&nbsp;<strong>{invoice_status}<br /></strong><br />Thank you for your confidence.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (66, 'contract', 'contract-expiration-to-staff', 'english', 'Contract Expiration Reminder (Sent to Staff)', 'Contract Expiration Reminder', 'Hi {staff_firstname}<br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (67, 'gdpr', 'gdpr-removal-request', 'english', 'Removal Request From Contact (Sent to administrators)', 'Data Removal Request Received', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by&nbsp;{contact_firstname} {contact_lastname}<br /><br />You can review this request and take proper actions directly from the admin area.', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (68, 'gdpr', 'gdpr-removal-request-lead', 'english', 'Removal Request From Lead (Sent to administrators)', 'Data Removal Request Received', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by {lead_name}<br /><br />You can review this request and take proper actions directly from the admin area.<br /><br />To view the lead inside the admin area click here:&nbsp;<a href=\"{lead_link}\">{lead_link}</a>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (69, 'client', 'client-registration-confirmed', 'english', 'Customer Registration Confirmed', 'Your registration is confirmed', '<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{crm_url}\">{crm_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n<p><br />(This is an automated email, so please don\'t reply to this email address)</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (70, 'contract', 'contract-signed-to-staff', 'english', 'Contract Signed (Sent to Staff)', 'Customer Signed a Contract', 'Hi {staff_firstname}<br /><br />A contract with subject&nbsp;<strong>{contract_subject} </strong>has been successfully signed by the customer.<br /><br />You can view the contract at the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (71, 'subscriptions', 'customer-subscribed-to-staff', 'english', 'Customer Subscribed to a Subscription (Sent to administrators and subscription creator)', 'Customer Subscribed to a Subscription', 'The customer <strong>{client_company}</strong> subscribed to a subscription with name&nbsp;<strong>{subscription_name}</strong><br /><br /><strong>ID</strong>:&nbsp;{subscription_id}<br /><strong>Subscription name</strong>:&nbsp;{subscription_name}<br /><strong>Subscription description</strong>:&nbsp;{subscription_description}<br /><br />You can view the subscription by clicking <a href=\"{subscription_link}\">here</a><br />\r\n<div style=\"text-align: center;\"><span style=\"font-size: 10pt;\">&nbsp;</span></div>\r\nBest Regards,<br />{email_signature}<br /><br /><span style=\"font-size: 10pt;\"><span style=\"color: #999999;\">You are receiving this email because you are either administrator or you are creator of the subscription.</span></span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (72, 'client', 'contact-verification-email', 'english', 'Email Verification (Sent to Contact After Registration)', 'Verify Email Address', '<p>Hello&nbsp;{contact_firstname}<br /><br />Please click the button below to verify your email address.<br /><br /><a href=\"{email_verification_url}\">Verify Email Address</a><br /><br />If you did not create an account, no further action is required</p>\r\n<p><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (73, 'client', 'new-customer-profile-file-uploaded-to-staff', 'english', 'New Customer Profile File(s) Uploaded (Sent to Staff)', 'Customer Uploaded New File(s) in Profile', 'Hi!<br /><br />New file(s) is uploaded into the customer ({client_company}) profile by&nbsp;{contact_firstname}<br /><br />You can check the uploaded files into the admin area by clicking <a href=\"{customer_profile_files_admin_link}\">here</a> or at the following link:&nbsp;{customer_profile_files_admin_link}<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (74, 'staff', 'event-notification-to-staff', 'english', 'Event Notification (Calendar)', 'Upcoming Event - {event_title}', 'Hi {staff_firstname}! <br /><br />This is a reminder for event <a href=\\\"{event_link}\\\">{event_title}</a> scheduled at {event_start_date}. <br /><br />Regards.', '', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (75, 'subscriptions', 'subscription-payment-requires-action', 'english', 'Credit Card Authorization Required - SCA', 'Important: Confirm your subscription {subscription_name} payment', '<p>Hello {contact_firstname}</p>\r\n<p><strong>Your bank sometimes requires an additional step to make sure an online transaction was authorized.</strong><br /><br />Because of European regulation to protect consumers, many online payments now require two-factor authentication. Your bank ultimately decides when authentication is required to confirm a payment, but you may notice this step when you start paying for a service or when the cost changes.<br /><br />In order to pay the subscription <strong>{subscription_name}</strong>, you will need to&nbsp;confirm your payment by clicking on the follow link: <strong><a href=\"{subscription_authorize_payment_link}\">{subscription_authorize_payment_link}</a></strong><br /><br />To view the subscription, please click at the following link: <a href=\"{subscription_link}\"><span>{subscription_link}</span></a><br />or you can login in our dedicated area here: <a href=\"{crm_url}/login\">{crm_url}/login</a> in case you want to update your credit card or view the subscriptions you are subscribed.<br /><br />Best Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);


#
# TABLE STRUCTURE FOR: tblestimates
#

DROP TABLE IF EXISTS `tblestimates`;

CREATE TABLE `tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '0',
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `clientnote` text,
  `adminnote` text,
  `discount_percent` decimal(15,2) DEFAULT '0.00',
  `discount_total` decimal(15,2) DEFAULT '0.00',
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT '0',
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `pipeline_order` int(11) NOT NULL DEFAULT '0',
  `is_expiry_notified` int(11) NOT NULL DEFAULT '0',
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblevents
#

DROP TABLE IF EXISTS `tblevents`;

CREATE TABLE `tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` mediumtext NOT NULL,
  `description` text,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT '0',
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT '0',
  `reminder_before` int(11) NOT NULL DEFAULT '0',
  `reminder_before_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblexpenses
#

DROP TABLE IF EXISTS `tblexpenses`;

CREATE TABLE `tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT '0',
  `reference_no` varchar(100) DEFAULT NULL,
  `note` text,
  `expense_name` varchar(191) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `billable` int(11) DEFAULT '0',
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `cycles` int(11) NOT NULL DEFAULT '0',
  `total_cycles` int(11) NOT NULL DEFAULT '0',
  `custom_recurring` int(11) NOT NULL DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblexpenses_categories
#

DROP TABLE IF EXISTS `tblexpenses_categories`;

CREATE TABLE `tblexpenses_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblfiles
#

DROP TABLE IF EXISTS `tblfiles`;

CREATE TABLE `tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT '0',
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` text,
  `thumbnail_link` text COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT '0',
  `task_comment_id` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblform_question_box
#

DROP TABLE IF EXISTS `tblform_question_box`;

CREATE TABLE `tblform_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblform_question_box_description
#

DROP TABLE IF EXISTS `tblform_question_box_description`;

CREATE TABLE `tblform_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblform_questions
#

DROP TABLE IF EXISTS `tblform_questions`;

CREATE TABLE `tblform_questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblform_results
#

DROP TABLE IF EXISTS `tblform_results`;

CREATE TABLE `tblform_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` text,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblgdpr_requests
#

DROP TABLE IF EXISTS `tblgdpr_requests`;

CREATE TABLE `tblgdpr_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL DEFAULT '0',
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `lead_id` int(11) NOT NULL DEFAULT '0',
  `request_type` varchar(191) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoicepaymentrecords
#

DROP TABLE IF EXISTS `tblinvoicepaymentrecords`;

CREATE TABLE `tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(191) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoices
#

DROP TABLE IF EXISTS `tblinvoices`;

CREATE TABLE `tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT '0',
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT '1',
  `clientnote` text,
  `adminnote` text,
  `last_overdue_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT '0',
  `allowed_payment_modes` mediumtext,
  `token` mediumtext,
  `discount_percent` decimal(15,2) DEFAULT '0.00',
  `discount_total` decimal(15,2) DEFAULT '0.00',
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `cycles` int(11) NOT NULL DEFAULT '0',
  `total_cycles` int(11) NOT NULL DEFAULT '0',
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` text,
  `sale_agent` int(11) NOT NULL DEFAULT '0',
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT '1',
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `project_id` int(11) DEFAULT '0',
  `subscription_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitem_tax
#

DROP TABLE IF EXISTS `tblitem_tax`;

CREATE TABLE `tblitem_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitemable
#

DROP TABLE IF EXISTS `tblitemable`;

CREATE TABLE `tblitemable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` mediumtext NOT NULL,
  `long_description` mediumtext,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitems
#

DROP TABLE IF EXISTS `tblitems`;

CREATE TABLE `tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `long_description` text,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitems_groups
#

DROP TABLE IF EXISTS `tblitems_groups`;

CREATE TABLE `tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowedge_base_article_feedback
#

DROP TABLE IF EXISTS `tblknowedge_base_article_feedback`;

CREATE TABLE `tblknowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledge_base
#

DROP TABLE IF EXISTS `tblknowledge_base`;

CREATE TABLE `tblknowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  `description` text NOT NULL,
  `slug` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT '0',
  `staff_article` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledge_base_groups
#

DROP TABLE IF EXISTS `tblknowledge_base_groups`;

CREATE TABLE `tblknowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` text,
  `description` mediumtext,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT '0',
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbllead_activity_log
#

DROP TABLE IF EXISTS `tbllead_activity_log`;

CREATE TABLE `tbllead_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` text,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbllead_integration_emails
#

DROP TABLE IF EXISTS `tbllead_integration_emails`;

CREATE TABLE `tbllead_integration_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext,
  `body` mediumtext,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleads
#

DROP TABLE IF EXISTS `tblleads`;

CREATE TABLE `tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `description` text,
  `country` int(11) NOT NULL DEFAULT '0',
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `leadorder` int(11) DEFAULT '1',
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT '0',
  `junk` int(11) NOT NULL DEFAULT '0',
  `last_lead_status` int(11) NOT NULL DEFAULT '0',
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT '0',
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleads_email_integration
#

DROP TABLE IF EXISTS `tblleads_email_integration`;

CREATE TABLE `tblleads_email_integration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` mediumtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT '5',
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT '1',
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT '1',
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext,
  `mark_public` int(11) NOT NULL DEFAULT '0',
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT '1',
  `delete_after_import` int(11) NOT NULL DEFAULT '0',
  `create_task_if_customer` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblleads_email_integration` (`id`, `active`, `email`, `imap_server`, `password`, `check_every`, `responsible`, `lead_source`, `lead_status`, `encryption`, `folder`, `last_run`, `notify_lead_imported`, `notify_lead_contact_more_times`, `notify_type`, `notify_ids`, `mark_public`, `only_loop_on_unseen_emails`, `delete_after_import`, `create_task_if_customer`) VALUES (1, 0, '', '', '', 10, 0, 0, 0, 'tls', 'inbox', '', 1, 1, 'assigned', '', 0, 1, 0, 1);


#
# TABLE STRUCTURE FOR: tblleads_sources
#

DROP TABLE IF EXISTS `tblleads_sources`;

CREATE TABLE `tblleads_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblleads_sources` (`id`, `name`) VALUES (2, 'Facebook');
INSERT INTO `tblleads_sources` (`id`, `name`) VALUES (1, 'Google');


#
# TABLE STRUCTURE FOR: tblleads_status
#

DROP TABLE IF EXISTS `tblleads_status`;

CREATE TABLE `tblleads_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (1, 'Customer', 1000, '#7cb342', 1);


#
# TABLE STRUCTURE FOR: tbllistemails
#

DROP TABLE IF EXISTS `tbllistemails`;

CREATE TABLE `tbllistemails` (
  `emailid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmail_queue
#

DROP TABLE IF EXISTS `tblmail_queue`;

CREATE TABLE `tblmail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `cc` text,
  `bcc` text,
  `message` mediumtext NOT NULL,
  `alt_message` mediumtext,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` text,
  `attachments` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmaillistscustomfields
#

DROP TABLE IF EXISTS `tblmaillistscustomfields`;

CREATE TABLE `tblmaillistscustomfields` (
  `customfieldid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `fieldname` varchar(150) NOT NULL,
  `fieldslug` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmaillistscustomfieldvalues
#

DROP TABLE IF EXISTS `tblmaillistscustomfieldvalues`;

CREATE TABLE `tblmaillistscustomfieldvalues` (
  `customfieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `listid` int(11) NOT NULL,
  `customfieldid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`customfieldvalueid`),
  KEY `listid` (`listid`),
  KEY `customfieldid` (`customfieldid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmigrations
#

DROP TABLE IF EXISTS `tblmigrations`;

CREATE TABLE `tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblmigrations` (`version`) VALUES ('240');


#
# TABLE STRUCTURE FOR: tblmilestones
#

DROP TABLE IF EXISTS `tblmilestones`;

CREATE TABLE `tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text,
  `description_visible_to_customer` tinyint(1) DEFAULT '0',
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT '0',
  `datecreated` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmodules
#

DROP TABLE IF EXISTS `tblmodules`;

CREATE TABLE `tblmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (1, 'backup', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (2, 'surveys', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (3, 'theme_style', '2.3.0', 1);


#
# TABLE STRUCTURE FOR: tblnewsfeed_comment_likes
#

DROP TABLE IF EXISTS `tblnewsfeed_comment_likes`;

CREATE TABLE `tblnewsfeed_comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnewsfeed_post_comments
#

DROP TABLE IF EXISTS `tblnewsfeed_post_comments`;

CREATE TABLE `tblnewsfeed_post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnewsfeed_post_likes
#

DROP TABLE IF EXISTS `tblnewsfeed_post_likes`;

CREATE TABLE `tblnewsfeed_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnewsfeed_posts
#

DROP TABLE IF EXISTS `tblnewsfeed_posts`;

CREATE TABLE `tblnewsfeed_posts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnotes
#

DROP TABLE IF EXISTS `tblnotes`;

CREATE TABLE `tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` text,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnotifications
#

DROP TABLE IF EXISTS `tblnotifications`;

CREATE TABLE `tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT '0',
  `isread_inline` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT '0',
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` mediumtext,
  `additional_data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbloptions
#

DROP TABLE IF EXISTS `tbloptions`;

CREATE TABLE `tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=421 DEFAULT CHARSET=utf8;

INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (1, 'dateformat', 'd-m-Y|%d-%m-%Y', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (2, 'companyname', 'Enerlytics (Pty) Ltd', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (3, 'services', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (4, 'maximum_allowed_ticket_attachments', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (5, 'ticket_attachments_file_extensions', '.jpg,.png,.pdf,.doc,.zip,.rar', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (6, 'staff_access_only_assigned_departments', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (7, 'use_knowledge_base', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (8, 'smtp_email', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (9, 'smtp_password', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (10, 'company_info_format', '{company_name}<br />\r\n{address}<br />\r\n{city} {state}<br />\r\n{country_code} {zip_code}<br />\r\n{vat_number_with_label}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (11, 'smtp_port', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (12, 'smtp_host', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (13, 'smtp_email_charset', 'utf-8', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (14, 'default_timezone', 'Africa/Johannesburg', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (15, 'clients_default_theme', 'perfex', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (16, 'company_logo', 'logo.png', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (17, 'tables_pagination_limit', '25', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (18, 'main_domain', 'http://www.enerlytics.co.za/', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (19, 'allow_registration', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (20, 'knowledge_base_without_registration', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (21, 'email_signature', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (22, 'default_staff_role', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (23, 'newsfeed_maximum_files_upload', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (24, 'contract_expiration_before', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (25, 'invoice_prefix', 'INV-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (26, 'decimal_separator', '.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (27, 'thousand_separator', ',', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (28, 'invoice_company_name', 'Enerlytics (Pty) Ltd', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (29, 'invoice_company_address', '64-74 White Road, Retreat', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (30, 'invoice_company_city', 'Cape Town', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (31, 'invoice_company_country_code', 'South Africa', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (32, 'invoice_company_postal_code', '7640', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (33, 'invoice_company_phonenumber', '+27 (0) 21 902 0722', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (34, 'view_invoice_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (35, 'invoice_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (36, 'next_invoice_number', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (37, 'active_language', 'english', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (38, 'invoice_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (39, 'automatically_send_invoice_overdue_reminder_after', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (40, 'automatically_resend_invoice_overdue_reminder_after', '3', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (41, 'expenses_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (42, 'delete_only_on_last_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (43, 'delete_only_on_last_estimate', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (44, 'create_invoice_from_recurring_only_on_paid_invoices', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (45, 'allow_payment_amount_to_be_modified', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (46, 'rtl_support_client', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (47, 'limit_top_search_bar_results_to', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (48, 'estimate_prefix', 'EST-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (49, 'next_estimate_number', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (50, 'estimate_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (51, 'estimate_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (52, 'estimate_auto_convert_to_invoice_on_client_accept', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (53, 'exclude_estimate_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (54, 'rtl_support_admin', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (55, 'last_cron_run', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (56, 'show_sale_agent_on_estimates', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (57, 'show_sale_agent_on_invoices', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (58, 'predefined_terms_invoice', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (59, 'predefined_terms_estimate', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (60, 'default_task_priority', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (61, 'dropbox_app_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (62, 'show_expense_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (63, 'only_show_contact_tickets', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (64, 'predefined_clientnote_invoice', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (65, 'predefined_clientnote_estimate', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (66, 'custom_pdf_logo_image_url', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (67, 'favicon', 'favicon.png', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (68, 'invoice_due_after', '30', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (69, 'google_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (70, 'google_calendar_main_calendar', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (71, 'default_tax', 'a:0:{}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (72, 'show_invoices_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (73, 'show_estimates_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (74, 'show_contracts_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (75, 'show_tasks_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (76, 'show_customer_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (77, 'output_client_pdfs_from_admin_area_in_client_language', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (78, 'show_lead_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (79, 'send_estimate_expiry_reminder_before', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (80, 'leads_default_source', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (81, 'leads_default_status', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (82, 'proposal_expiry_reminder_enabled', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (83, 'send_proposal_expiry_reminder_before', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (84, 'default_contact_permissions', 'a:6:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (85, 'pdf_logo_width', '150', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (86, 'access_tickets_to_none_staff_members', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (87, 'customer_default_country', '205', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (88, 'view_estimate_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (89, 'show_status_on_pdf_ei', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (90, 'email_piping_only_replies', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (91, 'email_piping_only_registered', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (92, 'default_view_calendar', 'month', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (93, 'email_piping_default_priority', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (94, 'total_to_words_lowercase', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (95, 'show_tax_per_item', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (96, 'total_to_words_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (97, 'receive_notification_on_new_ticket', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (98, 'autoclose_tickets_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (99, 'media_max_file_size_upload', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (100, 'client_staff_add_edit_delete_task_comments_first_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (101, 'show_projects_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (102, 'leads_kanban_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (103, 'tasks_reminder_notification_before', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (104, 'pdf_font', 'freesans', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (105, 'pdf_table_heading_color', '#323a45', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (106, 'pdf_table_heading_text_color', '#ffffff', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (107, 'pdf_font_size', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (108, 'default_leads_kanban_sort', 'leadorder', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (109, 'default_leads_kanban_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (110, 'allowed_files', '.png,.jpg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (111, 'show_all_tasks_for_project_member', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (112, 'email_protocol', 'smtp', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (113, 'calendar_first_day', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (114, 'recaptcha_secret_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (115, 'show_help_on_setup_menu', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (116, 'show_proposals_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (117, 'smtp_encryption', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (118, 'recaptcha_site_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (119, 'smtp_username', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (120, 'auto_stop_tasks_timers_on_new_timer', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (121, 'notification_when_customer_pay_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (122, 'calendar_invoice_color', '#ff6f00', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (123, 'calendar_estimate_color', '#ff6f00', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (124, 'calendar_proposal_color', '#84c529', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (125, 'new_task_auto_assign_current_member', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (126, 'calendar_reminder_color', '#03a9f4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (127, 'calendar_contract_color', '#b72974', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (128, 'calendar_project_color', '#b72974', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (129, 'update_info_message', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (130, 'show_estimate_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (131, 'show_invoice_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (132, 'show_proposal_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (133, 'proposal_due_after', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (134, 'allow_customer_to_change_ticket_status', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (135, 'lead_lock_after_convert_to_customer', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (136, 'default_proposals_pipeline_sort', 'pipeline_order', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (137, 'default_proposals_pipeline_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (138, 'default_estimates_pipeline_sort', 'pipeline_order', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (139, 'default_estimates_pipeline_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (140, 'use_recaptcha_customers_area', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (141, 'remove_decimals_on_zero', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (142, 'remove_tax_name_from_item_table', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (143, 'pdf_format_invoice', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (144, 'pdf_format_estimate', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (145, 'pdf_format_proposal', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (146, 'pdf_format_payment', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (147, 'pdf_format_contract', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (148, 'swap_pdf_info', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (149, 'exclude_invoice_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (150, 'cron_has_run_from_cli', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (151, 'hide_cron_is_required_message', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (152, 'auto_assign_customer_admin_after_lead_convert', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (153, 'show_transactions_on_invoice_pdf', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (154, 'show_pay_link_to_invoice_pdf', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (155, 'tasks_kanban_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (156, 'purchase_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (157, 'estimates_pipeline_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (158, 'proposals_pipeline_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (159, 'proposal_number_prefix', 'PRO-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (160, 'number_padding_prefixes', '6', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (161, 'show_page_number_on_pdf', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (162, 'calendar_events_limit', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (163, 'show_setup_menu_item_only_on_hover', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (164, 'company_requires_vat_number_field', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (165, 'company_is_required', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (166, 'allow_contact_to_delete_files', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (167, 'company_vat', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (168, 'di', '1568729799', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (169, 'invoice_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (170, 'use_minified_files', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (171, 'only_own_files_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (172, 'allow_primary_contact_to_view_edit_billing_and_shipping', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (173, 'estimate_due_after', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (174, 'staff_members_open_tickets_to_all_contacts', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (175, 'time_format', '24', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (176, 'delete_activity_log_older_then', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (177, 'disable_language', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (178, 'company_state', 'Western Cape', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (179, 'email_header', '<!doctype html>\n                            <html>\n                            <head>\n                              <meta name=\"viewport\" content=\"width=device-width\" />\n                              <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n                              <style>\n                                body {\n                                 background-color: #f6f6f6;\n                                 font-family: sans-serif;\n                                 -webkit-font-smoothing: antialiased;\n                                 font-size: 14px;\n                                 line-height: 1.4;\n                                 margin: 0;\n                                 padding: 0;\n                                 -ms-text-size-adjust: 100%;\n                                 -webkit-text-size-adjust: 100%;\n                               }\n                               table {\n                                 border-collapse: separate;\n                                 mso-table-lspace: 0pt;\n                                 mso-table-rspace: 0pt;\n                                 width: 100%;\n                               }\n                               table td {\n                                 font-family: sans-serif;\n                                 font-size: 14px;\n                                 vertical-align: top;\n                               }\n                                   /* -------------------------------------\n                                     BODY & CONTAINER\n                                     ------------------------------------- */\n                                     .body {\n                                       background-color: #f6f6f6;\n                                       width: 100%;\n                                     }\n                                     /* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */\n\n                                     .container {\n                                       display: block;\n                                       margin: 0 auto !important;\n                                       /* makes it centered */\n                                       max-width: 680px;\n                                       padding: 10px;\n                                       width: 680px;\n                                     }\n                                     /* This should also be a block element, so that it will fill 100% of the .container */\n\n                                     .content {\n                                       box-sizing: border-box;\n                                       display: block;\n                                       margin: 0 auto;\n                                       max-width: 680px;\n                                       padding: 10px;\n                                     }\n                                   /* -------------------------------------\n                                     HEADER, FOOTER, MAIN\n                                     ------------------------------------- */\n\n                                     .main {\n                                       background: #fff;\n                                       border-radius: 3px;\n                                       width: 100%;\n                                     }\n                                     .wrapper {\n                                       box-sizing: border-box;\n                                       padding: 20px;\n                                     }\n                                     .footer {\n                                       clear: both;\n                                       padding-top: 10px;\n                                       text-align: center;\n                                       width: 100%;\n                                     }\n                                     .footer td,\n                                     .footer p,\n                                     .footer span,\n                                     .footer a {\n                                       color: #999999;\n                                       font-size: 12px;\n                                       text-align: center;\n                                     }\n                                     hr {\n                                       border: 0;\n                                       border-bottom: 1px solid #f6f6f6;\n                                       margin: 20px 0;\n                                     }\n                                   /* -------------------------------------\n                                     RESPONSIVE AND MOBILE FRIENDLY STYLES\n                                     ------------------------------------- */\n\n                                     @media only screen and (max-width: 620px) {\n                                       table[class=body] .content {\n                                         padding: 0 !important;\n                                       }\n                                       table[class=body] .container {\n                                         padding: 0 !important;\n                                         width: 100% !important;\n                                       }\n                                       table[class=body] .main {\n                                         border-left-width: 0 !important;\n                                         border-radius: 0 !important;\n                                         border-right-width: 0 !important;\n                                       }\n                                     }\n                                   </style>\n                                 </head>\n                                 <body class=\"\">\n                                  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"body\">\n                                    <tr>\n                                     <td>&nbsp;</td>\n                                     <td class=\"container\">\n                                      <div class=\"content\">\n                                        <!-- START CENTERED WHITE CONTAINER -->\n                                        <table class=\"main\">\n                                          <!-- START MAIN CONTENT AREA -->\n                                          <tr>\n                                           <td class=\"wrapper\">\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n                                              <tr>\n                                               <td>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (180, 'show_pdf_signature_invoice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (181, 'show_pdf_signature_estimate', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (182, 'signature_image', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (183, 'scroll_responsive_tables', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (184, 'email_footer', '</td>\n                             </tr>\n                           </table>\n                         </td>\n                       </tr>\n                       <!-- END MAIN CONTENT AREA -->\n                     </table>\n                     <!-- START FOOTER -->\n                     <div class=\"footer\">\n                      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n                        <tr>\n                          <td class=\"content-block\">\n                            <span>{companyname}</span>\n                          </td>\n                        </tr>\n                      </table>\n                    </div>\n                    <!-- END FOOTER -->\n                    <!-- END CENTERED WHITE CONTAINER -->\n                  </div>\n                </td>\n                <td>&nbsp;</td>\n              </tr>\n            </table>\n            </body>\n            </html>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (185, 'exclude_proposal_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (186, 'pusher_app_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (187, 'pusher_app_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (188, 'pusher_app_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (189, 'pusher_realtime_notifications', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (190, 'pdf_format_statement', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (191, 'pusher_cluster', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (192, 'show_table_export_button', 'to_all', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (193, 'allow_staff_view_proposals_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (194, 'show_cloudflare_notice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (195, 'task_modal_class', 'modal-lg', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (196, 'lead_modal_class', 'modal-lg', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (197, 'show_timesheets_overview_all_members_notice_admins', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (198, 'desktop_notifications', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (199, 'hide_notified_reminders_from_calendar', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (200, 'customer_info_format', '{company_name}<br />\r\n{street}<br />\r\n{city} {state}<br />\r\n{country_code} {zip_code}<br />\r\n{vat_number_with_label}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (201, 'timer_started_change_status_in_progress', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (202, 'default_ticket_reply_status', '3', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (203, 'default_task_status', 'auto', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (204, 'email_queue_skip_with_attachments', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (205, 'email_queue_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (206, 'last_email_queue_retry', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (207, 'auto_dismiss_desktop_notifications_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (208, 'proposal_info_format', '{proposal_to}<br />\r\n{address}<br />\r\n{city} {state}<br />\r\n{country_code} {zip_code}<br />\r\n{phone}<br />\r\n{email}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (209, 'ticket_replies_order', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (210, 'new_recurring_invoice_action', 'generate_and_send', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (211, 'bcc_emails', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (212, 'email_templates_language_checks', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (213, 'proposal_accept_identity_confirmation', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (214, 'estimate_accept_identity_confirmation', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (215, 'new_task_auto_follower_current_member', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (216, 'task_biillable_checked_on_creation', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (217, 'predefined_clientnote_credit_note', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (218, 'predefined_terms_credit_note', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (219, 'next_credit_note_number', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (220, 'credit_note_prefix', 'CN-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (221, 'credit_note_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (222, 'pdf_format_credit_note', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (223, 'show_pdf_signature_credit_note', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (224, 'show_credit_note_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (225, 'show_amount_due_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (226, 'show_total_paid_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (227, 'show_credits_applied_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (228, 'staff_members_create_inline_lead_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (229, 'staff_members_create_inline_customer_groups', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (230, 'staff_members_create_inline_ticket_services', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (231, 'staff_members_save_tickets_predefined_replies', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (232, 'staff_members_create_inline_contract_types', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (233, 'staff_members_create_inline_expense_categories', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (234, 'show_project_on_credit_note', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (235, 'proposals_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (236, 'estimates_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (237, 'contracts_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (238, 'credit_note_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (239, 'allow_non_admin_members_to_import_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (240, 'e_sign_legal_text', 'By clicking on \"Sign\", I consent to be legally bound by this electronic representation of my signature.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (241, 'show_pdf_signature_contract', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (242, 'view_contract_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (243, 'show_subscriptions_in_customers_area', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (244, 'calendar_only_assigned_tasks', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (245, 'after_subscription_payment_captured', 'send_invoice_and_receipt', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (246, 'mail_engine', 'phpmailer', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (247, 'gdpr_enable_terms_and_conditions', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (248, 'privacy_policy', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (249, 'terms_and_conditions', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (250, 'gdpr_enable_terms_and_conditions_lead_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (251, 'gdpr_enable_terms_and_conditions_ticket_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (252, 'gdpr_contact_enable_right_to_be_forgotten', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (253, 'show_gdpr_in_customers_menu', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (254, 'show_gdpr_link_in_footer', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (255, 'enable_gdpr', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (256, 'gdpr_on_forgotten_remove_invoices_credit_notes', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (257, 'gdpr_on_forgotten_remove_estimates', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (258, 'gdpr_enable_consent_for_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (259, 'gdpr_consent_public_page_top_block', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (260, 'gdpr_page_top_information_block', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (261, 'gdpr_enable_lead_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (262, 'gdpr_show_lead_custom_fields_on_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (263, 'gdpr_lead_attachments_on_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (264, 'gdpr_enable_consent_for_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (265, 'gdpr_lead_enable_right_to_be_forgotten', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (266, 'allow_staff_view_invoices_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (267, 'gdpr_data_portability_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (268, 'gdpr_lead_data_portability_allowed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (269, 'gdpr_contact_data_portability_allowed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (270, 'gdpr_data_portability_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (271, 'allow_staff_view_estimates_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (272, 'gdpr_after_lead_converted_delete', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (273, 'gdpr_show_terms_and_conditions_in_footer', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (274, 'save_last_order_for_tables', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (275, 'company_logo_dark', 'logo_dark.png', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (276, 'customers_register_require_confirmation', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (277, 'allow_non_admin_staff_to_delete_ticket_attachments', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (278, 'receive_notification_on_new_ticket_replies', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (279, 'google_client_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (280, 'enable_google_picker', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (281, 'show_ticket_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (282, 'ticket_import_reply_only', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (283, 'visible_customer_profile_tabs', 'all', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (284, 'show_project_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (285, 'show_project_on_estimate', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (286, 'staff_members_create_inline_lead_source', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (287, 'lead_unique_validation', '[\"email\"]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (288, 'last_upgrade_copy_data', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (289, 'custom_js_admin_scripts', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (290, 'custom_js_customer_scripts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (291, 'stripe_webhook_id', 'we_1FHV7w2b7f2Ftl9HRwz1EqnU', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (292, 'stripe_webhook_signing_secret', 'whsec_BsAmRWKhKiKDylJeCB4jSY4MfdiP7RaM', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (293, 'upgraded_from_version', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (294, 'stripe_ideal_webhook_id', 'we_1FHV8m2b7f2Ftl9HdN9PCVgx', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (295, 'stripe_ideal_webhook_signing_secret', 'whsec_3xZq5jRrNQhq2wP1SuqdqjMop21vChkG', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (296, 'sms_clickatell_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (297, 'sms_clickatell_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (298, 'sms_clickatell_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (299, 'sms_msg91_sender_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (300, 'sms_msg91_auth_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (301, 'sms_msg91_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (302, 'sms_msg91_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (303, 'sms_twilio_account_sid', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (304, 'sms_twilio_auth_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (305, 'sms_twilio_phone_number', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (306, 'sms_twilio_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (307, 'sms_twilio_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (308, 'paymentmethod_authorize_aim_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (309, 'paymentmethod_authorize_aim_label', 'Authorize.net AIM', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (310, 'paymentmethod_authorize_aim_api_login_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (311, 'paymentmethod_authorize_aim_api_transaction_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (312, 'paymentmethod_authorize_aim_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (313, 'paymentmethod_authorize_aim_currencies', 'USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (314, 'paymentmethod_authorize_aim_test_mode_enabled', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (315, 'paymentmethod_authorize_aim_developer_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (316, 'paymentmethod_authorize_aim_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (317, 'paymentmethod_authorize_aim_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (318, 'paymentmethod_authorize_sim_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (319, 'paymentmethod_authorize_sim_label', 'Authorize.net SIM', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (320, 'paymentmethod_authorize_sim_api_login_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (321, 'paymentmethod_authorize_sim_api_transaction_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (322, 'paymentmethod_authorize_sim_api_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (323, 'paymentmethod_authorize_sim_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (324, 'paymentmethod_authorize_sim_currencies', 'USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (325, 'paymentmethod_authorize_sim_test_mode_enabled', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (326, 'paymentmethod_authorize_sim_developer_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (327, 'paymentmethod_authorize_sim_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (328, 'paymentmethod_authorize_sim_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (329, 'paymentmethod_instamojo_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (330, 'paymentmethod_instamojo_label', 'Instamojo', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (331, 'paymentmethod_instamojo_api_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (332, 'paymentmethod_instamojo_auth_token', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (333, 'paymentmethod_instamojo_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (334, 'paymentmethod_instamojo_currencies', 'INR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (335, 'paymentmethod_instamojo_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (336, 'paymentmethod_instamojo_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (337, 'paymentmethod_instamojo_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (338, 'paymentmethod_mollie_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (339, 'paymentmethod_mollie_label', 'Mollie', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (340, 'paymentmethod_mollie_api_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (341, 'paymentmethod_mollie_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (342, 'paymentmethod_mollie_currencies', 'EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (343, 'paymentmethod_mollie_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (344, 'paymentmethod_mollie_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (345, 'paymentmethod_mollie_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (346, 'paymentmethod_paypal_braintree_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (347, 'paymentmethod_paypal_braintree_label', 'Braintree', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (348, 'paymentmethod_paypal_braintree_merchant_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (349, 'paymentmethod_paypal_braintree_api_public_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (350, 'paymentmethod_paypal_braintree_api_private_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (351, 'paymentmethod_paypal_braintree_currencies', 'USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (352, 'paymentmethod_paypal_braintree_paypal_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (353, 'paymentmethod_paypal_braintree_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (354, 'paymentmethod_paypal_braintree_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (355, 'paymentmethod_paypal_braintree_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (356, 'paymentmethod_paypal_checkout_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (357, 'paymentmethod_paypal_checkout_label', 'Paypal Smart Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (358, 'paymentmethod_paypal_checkout_client_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (359, 'paymentmethod_paypal_checkout_secret', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (360, 'paymentmethod_paypal_checkout_payment_description', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (361, 'paymentmethod_paypal_checkout_currencies', 'USD,CAD,EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (362, 'paymentmethod_paypal_checkout_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (363, 'paymentmethod_paypal_checkout_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (364, 'paymentmethod_paypal_checkout_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (365, 'paymentmethod_paypal_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (366, 'paymentmethod_paypal_label', 'Paypal', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (367, 'paymentmethod_paypal_username', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (368, 'paymentmethod_paypal_password', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (369, 'paymentmethod_paypal_signature', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (370, 'paymentmethod_paypal_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (371, 'paymentmethod_paypal_currencies', 'EUR,USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (372, 'paymentmethod_paypal_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (373, 'paymentmethod_paypal_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (374, 'paymentmethod_paypal_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (375, 'paymentmethod_payu_money_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (376, 'paymentmethod_payu_money_label', 'PayU Money', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (377, 'paymentmethod_payu_money_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (378, 'paymentmethod_payu_money_salt', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (379, 'paymentmethod_payu_money_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (380, 'paymentmethod_payu_money_currencies', 'INR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (381, 'paymentmethod_payu_money_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (382, 'paymentmethod_payu_money_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (383, 'paymentmethod_payu_money_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (384, 'paymentmethod_stripe_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (385, 'paymentmethod_stripe_label', 'Stripe Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (386, 'paymentmethod_stripe_api_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (387, 'paymentmethod_stripe_api_publishable_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (388, 'paymentmethod_stripe_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (389, 'paymentmethod_stripe_currencies', 'USD,CAD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (390, 'paymentmethod_stripe_allow_primary_contact_to_update_credit_card', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (391, 'paymentmethod_stripe_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (392, 'paymentmethod_stripe_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (393, 'paymentmethod_stripe_ideal_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (394, 'paymentmethod_stripe_ideal_label', 'Stripe iDEAL', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (395, 'paymentmethod_stripe_ideal_api_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (396, 'paymentmethod_stripe_ideal_api_publishable_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (397, 'paymentmethod_stripe_ideal_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (398, 'paymentmethod_stripe_ideal_statement_descriptor', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (399, 'paymentmethod_stripe_ideal_currencies', 'EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (400, 'paymentmethod_stripe_ideal_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (401, 'paymentmethod_stripe_ideal_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (402, 'paymentmethod_two_checkout_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (403, 'paymentmethod_two_checkout_label', '2Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (404, 'paymentmethod_two_checkout_account_number', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (405, 'paymentmethod_two_checkout_private_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (406, 'paymentmethod_two_checkout_publishable_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (407, 'paymentmethod_two_checkout_currencies', 'USD,EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (408, 'paymentmethod_two_checkout_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (409, 'paymentmethod_two_checkout_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (410, 'paymentmethod_two_checkout_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (411, 'auto_backup_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (412, 'auto_backup_every', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (413, 'last_auto_backup', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (414, 'delete_backups_older_then', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (415, 'survey_send_emails_per_cron_run', '100', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (416, 'last_survey_send_cron', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (417, 'theme_style', '[{\"id\":\"admin-menu\",\"color\":\"#ebf4f9\"},{\"id\":\"admin-menu-links\",\"color\":\"#3f3f3f\"},{\"id\":\"user-welcome-text-color\",\"color\":\"#02a890\"},{\"id\":\"admin-menu-active-item-color\",\"color\":\"#3f3f3f\"},{\"id\":\"top-header\",\"color\":\"#ffffff\"},{\"id\":\"top-header-links\",\"color\":\"#3f3f3f\"}]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (418, 'theme_style_custom_admin_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (419, 'theme_style_custom_clients_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (420, 'theme_style_custom_clients_and_admin_area', '', 1);


#
# TABLE STRUCTURE FOR: tblpayment_modes
#

DROP TABLE IF EXISTS `tblpayment_modes`;

CREATE TABLE `tblpayment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `show_on_pdf` int(11) NOT NULL DEFAULT '0',
  `invoices_only` int(11) NOT NULL DEFAULT '0',
  `expenses_only` int(11) NOT NULL DEFAULT '0',
  `selected_by_default` int(11) NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblpayment_modes` (`id`, `name`, `description`, `show_on_pdf`, `invoices_only`, `expenses_only`, `selected_by_default`, `active`) VALUES (1, 'Bank', NULL, 0, 0, 0, 1, 1);


#
# TABLE STRUCTURE FOR: tblpinned_projects
#

DROP TABLE IF EXISTS `tblpinned_projects`;

CREATE TABLE `tblpinned_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproject_activity
#

DROP TABLE IF EXISTS `tblproject_activity`;

CREATE TABLE `tblproject_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT '0',
  `description_key` varchar(191) NOT NULL COMMENT 'Language file key',
  `additional_data` text,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproject_files
#

DROP TABLE IF EXISTS `tblproject_files`;

CREATE TABLE `tblproject_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) NOT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `description` text,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT '0',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `external` varchar(40) DEFAULT NULL,
  `external_link` text,
  `thumbnail_link` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproject_members
#

DROP TABLE IF EXISTS `tblproject_members`;

CREATE TABLE `tblproject_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproject_notes
#

DROP TABLE IF EXISTS `tblproject_notes`;

CREATE TABLE `tblproject_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproject_settings
#

DROP TABLE IF EXISTS `tblproject_settings`;

CREATE TABLE `tblproject_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectdiscussioncomments
#

DROP TABLE IF EXISTS `tblprojectdiscussioncomments`;

CREATE TABLE `tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` text NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT '0',
  `fullname` varchar(191) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectdiscussions
#

DROP TABLE IF EXISTS `tblprojectdiscussions`;

CREATE TABLE `tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT '0',
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT '0',
  `contact_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojects
#

DROP TABLE IF EXISTS `tblprojects`;

CREATE TABLE `tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text,
  `status` int(11) NOT NULL DEFAULT '0',
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT '0',
  `progress_from_tasks` int(11) NOT NULL DEFAULT '1',
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproposal_comments
#

DROP TABLE IF EXISTS `tblproposal_comments`;

CREATE TABLE `tblproposal_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproposals
#

DROP TABLE IF EXISTS `tblproposals`;

CREATE TABLE `tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) DEFAULT NULL,
  `content` longtext,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT '0.00',
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT '1',
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(191) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT '0',
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT '1',
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) NOT NULL DEFAULT '0',
  `is_expiry_notified` int(11) NOT NULL DEFAULT '0',
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblrelated_items
#

DROP TABLE IF EXISTS `tblrelated_items`;

CREATE TABLE `tblrelated_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblreminders
#

DROP TABLE IF EXISTS `tblreminders`;

CREATE TABLE `tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT '0',
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT '1',
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblroles
#

DROP TABLE IF EXISTS `tblroles`;

CREATE TABLE `tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `permissions` longtext,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (1, 'Employee', NULL);
INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (2, 'Management', 'a:18:{s:9:\"contracts\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:12:\"credit_notes\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:9:\"customers\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:9:\"estimates\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"expenses\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"invoices\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"items\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:14:\"knowledge_base\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"payments\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"projects\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:9:\"proposals\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:7:\"reports\";a:1:{i:0;s:4:\"view\";}s:5:\"roles\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"settings\";a:2:{i:0;s:4:\"view\";i:1;s:4:\"edit\";}s:5:\"staff\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:13:\"subscriptions\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"tasks\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"leads\";a:2:{i:0;s:4:\"view\";i:1;s:6:\"delete\";}}');


#
# TABLE STRUCTURE FOR: tblsales_activity
#

DROP TABLE IF EXISTS `tblsales_activity`;

CREATE TABLE `tblsales_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `additional_data` text,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblservices
#

DROP TABLE IF EXISTS `tblservices`;

CREATE TABLE `tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblservices` (`serviceid`, `name`) VALUES (1, 'Vending');
INSERT INTO `tblservices` (`serviceid`, `name`) VALUES (2, 'Token');
INSERT INTO `tblservices` (`serviceid`, `name`) VALUES (3, 'Faulty meter');


#
# TABLE STRUCTURE FOR: tblsessions
#

DROP TABLE IF EXISTS `tblsessions`;

CREATE TABLE `tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('026664f25563ac501ee56288c6b80df064a0d442', '105.187.39.213', 1568737187, '__ci_last_regenerate|i:1568737187;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a0af69276eccf6c2de2b6fa556b80a8536038ef', '105.228.160.195', 1568732501, '__ci_last_regenerate|i:1568732501;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0e1e74ee25048018914cd35efddabd41624496db', '105.228.160.195', 1568730911, '__ci_last_regenerate|i:1568730911;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0e5fba9c125c34687a9d8ecc080c4959791b3730', '207.241.230.164', 1568735745, '__ci_last_regenerate|i:1568735745;red_url|s:23:\"http://ems.119next.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('294ed21dec3e1ba37679f576322a3c12ad7a76f3', '105.187.39.213', 1568746405, '__ci_last_regenerate|i:1568746405;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2e831128b7c36aa2340ce591528d35d8b9bf3dfd', '105.187.39.213', 1568744805, '__ci_last_regenerate|i:1568744805;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3552456d2b642a0167dae7e2fcda843e9ad83228', '105.187.39.213', 1568744213, '__ci_last_regenerate|i:1568744213;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('38a3f80fecde17ee079a7b4d009151fc44ffc02b', '105.187.39.213', 1568733849, '__ci_last_regenerate|i:1568733849;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ec26e2e86c7cfa2aaa465a592cc86263e314b54', '105.187.39.213', 1568740166, '__ci_last_regenerate|i:1568740166;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4367d6e8dbcd6e75cd794ea772d9d7e6d8371a37', '207.241.227.104', 1568734783, '__ci_last_regenerate|i:1568734783;red_url|s:23:\"http://ems.119next.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46b449f6b32d7064818c5f265c09fa48f32d0ab9', '105.187.39.213', 1568750117, '__ci_last_regenerate|i:1568749895;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"4fba3e6768acf12343f5be879d0c5123\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568748064;}elFinderNetVolumes|a:0:{}tasks_kanban_view|s:5:\"false\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4c35eda6a08bbdb8cdd4e4adbeb3f7bb07cede4e', '105.228.160.195', 1568730584, '__ci_last_regenerate|i:1568730584;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('511ca2d60d1a3a23093aa8c1fa5e26d8c3f6b4f6', '105.187.39.213', 1568749895, '__ci_last_regenerate|i:1568749895;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"4fba3e6768acf12343f5be879d0c5123\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568748064;}elFinderNetVolumes|a:0:{}tasks_kanban_view|s:5:\"false\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d85548aaae1509d8f944d821de3066ac6b25d1f', '105.187.39.213', 1568738843, '__ci_last_regenerate|i:1568738843;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('626fc6488b9c031aa967f8eadd668b77e1fc81f2', '105.187.39.213', 1568736769, '__ci_last_regenerate|i:1568736769;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('643342ec5e74c8a8c4e1e06345e5f333e8234454', '207.241.225.217', 1568730289, '__ci_last_regenerate|i:1568730289;red_url|s:23:\"http://ems.119next.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('668ae64ebb1734cfb6e8777fa740aa8913b32eab', '105.187.39.213', 1568749173, '__ci_last_regenerate|i:1568749173;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"4fba3e6768acf12343f5be879d0c5123\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568748064;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6a7359e3095a0e616020d80f4b328849ea7d5e0a', '207.241.230.164', 1568733854, '__ci_last_regenerate|i:1568733854;red_url|s:23:\"http://ems.119next.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8d9404a0ea4b45f544dbb467f3ce13ddca85bc74', '207.241.230.164', 1568731559, '__ci_last_regenerate|i:1568731559;red_url|s:23:\"http://ems.119next.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('90837bbc8197bf9d078ea4c93bf697a3af632a1f', '105.187.39.213', 1568747451, '__ci_last_regenerate|i:1568747451;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9217706c5b17cc7bb89ea0b67f86356a18b93877', '105.187.39.213', 1568746729, '__ci_last_regenerate|i:1568746729;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('92e781863103cf1f0a67f2d29e0547f744a4f2fc', '105.187.39.213', 1568747104, '__ci_last_regenerate|i:1568747104;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('95441202192bcc3a8ec4d0d346bbd2d074fc621d', '105.187.39.213', 1568745377, '__ci_last_regenerate|i:1568745377;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('991dc92de848f466bad1a8bc6c0c06157082a5e1', '105.187.39.213', 1568735741, '__ci_last_regenerate|i:1568735741;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9e8401fc45861893e11dea370575d250beb8fc4e', '105.187.39.213', 1568747752, '__ci_last_regenerate|i:1568747752;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9ed528cf378176d34fe7c87801585d4d3bef769f', '207.241.225.217', 1568732169, '__ci_last_regenerate|i:1568732169;red_url|s:23:\"http://ems.119next.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ac27c64905313ba32b3ea584bc6c686993e5beca', '105.187.39.213', 1568734775, '__ci_last_regenerate|i:1568734775;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad4334ff1a1b0e076e3c574614bdc96cda415da8', '105.187.39.213', 1568746011, '__ci_last_regenerate|i:1568746011;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('afe7635e4f5da56fe9d9be33eed9495c8b542342', '105.228.160.195', 1568730260, '__ci_last_regenerate|i:1568730260;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;message-success|s:16:\"Settings Updated\";__ci_vars|a:2:{s:15:\"message-success\";s:3:\"old\";s:5:\"debug\";s:3:\"old\";}debug|s:103:\"Logo or Favicon change detected. If you still see the original CRM logo try to clear your browser cache\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b74fb6ad439e86685d8827d59a7cec8cd11901f2', '105.187.39.213', 1568737629, '__ci_last_regenerate|i:1568737629;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c0168d83db4c91aaf25b22fc973eb1f28732ff52', '105.187.39.213', 1568748063, '__ci_last_regenerate|i:1568748063;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"4fba3e6768acf12343f5be879d0c5123\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568747983;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cbea2a0eb900dc2a3f07503dc646c24450cebd57', '105.228.160.195', 1568731903, '__ci_last_regenerate|i:1568731903;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d106d7c3c1d59f9529acec5953ec7ffbd7b2d009', '105.187.39.213', 1568738155, '__ci_last_regenerate|i:1568738155;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"c2d86da49631a7566b01829a9baf6a32\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568209644;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:0:{}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568734032;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d46e7e5ea167bf56843f7b7bd615a16c1097d7a0', '105.187.39.213', 1568748368, '__ci_last_regenerate|i:1568748368;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"4fba3e6768acf12343f5be879d0c5123\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568748064;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db64e0bb5ccaebaf7b45803a1e7fafaaa985de22', '207.241.230.164', 1568736775, '__ci_last_regenerate|i:1568736775;red_url|s:23:\"http://ems.119next.com/\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ea538ca6789580e88bbf9c4da1cbb01bc7454550', '105.187.39.213', 1568748800, '__ci_last_regenerate|i:1568748800;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"4fba3e6768acf12343f5be879d0c5123\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568748064;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0cc52fd627433a3ba48d1753ffd74ed2a801b93', '105.228.160.195', 1568731554, '__ci_last_regenerate|i:1568731554;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f2371b31712c36425cd1c14226a15c54e1e2b364', '105.187.39.213', 1568749554, '__ci_last_regenerate|i:1568749554;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";elFinderCaches|a:6:{s:8:\"_optsMD5\";s:32:\"4fba3e6768acf12343f5be879d0c5123\";s:3:\"l1_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"7aca61d4a95f855be8a50f57942170c6\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l1_Lw\";s:4:\"name\";s:5:\"media\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:29:\"http://ems.119next.com/media/\";s:6:\"tmbUrl\";s:34:\"http://ems.119next.com/media/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l1_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:47:\"/usr/www/users/nextcwdmtm/ems.119next.com/media\";b:0;}}s:9:\"archivers\";a:2:{s:6:\"create\";a:5:{s:17:\"application/x-tar\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-cf\";s:3:\"ext\";s:3:\"tar\";}s:18:\"application/x-gzip\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-czf\";s:3:\"ext\";s:3:\"tgz\";}s:19:\"application/x-bzip2\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cjf\";s:3:\"ext\";s:3:\"tbz\";}s:16:\"application/x-xz\";a:3:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-cJf\";s:3:\"ext\";s:2:\"xz\";}s:15:\"application/zip\";a:3:{s:3:\"cmd\";s:3:\"zip\";s:4:\"argc\";s:6:\"-r9 -q\";s:3:\"ext\";s:3:\"zip\";}}s:7:\"extract\";a:5:{s:17:\"application/x-tar\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:3:\"-xf\";s:3:\"ext\";s:3:\"tar\";s:6:\"toSpec\";s:3:\"-C \";}s:18:\"application/x-gzip\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xzf\";s:3:\"ext\";s:3:\"tgz\";s:6:\"toSpec\";s:3:\"-C \";}s:19:\"application/x-bzip2\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xjf\";s:3:\"ext\";s:3:\"tbz\";s:6:\"toSpec\";s:3:\"-C \";}s:16:\"application/x-xz\";a:4:{s:3:\"cmd\";s:3:\"tar\";s:4:\"argc\";s:4:\"-xJf\";s:3:\"ext\";s:2:\"xz\";s:6:\"toSpec\";s:3:\"-C \";}s:15:\"application/zip\";a:4:{s:3:\"cmd\";s:5:\"unzip\";s:4:\"argc\";s:2:\"-q\";s:3:\"ext\";s:3:\"zip\";s:6:\"toSpec\";s:3:\"-d \";}}}s:8:\"videoLib\";s:0:\"\";s:3:\"l2_\";a:2:{s:8:\"rootstat\";a:1:{s:32:\"6f328146e8bc940768857b11a6ff1799\";a:14:{s:7:\"isowner\";b:0;s:2:\"ts\";i:1568734032;s:4:\"mime\";s:9:\"directory\";s:4:\"read\";i:1;s:5:\"write\";i:1;s:4:\"size\";i:0;s:4:\"hash\";s:5:\"l2_Lw\";s:4:\"name\";s:6:\"public\";s:7:\"rootRev\";s:0:\"\";s:7:\"options\";a:21:{s:4:\"path\";s:0:\"\";s:3:\"url\";s:36:\"http://ems.119next.com/media/public/\";s:6:\"tmbUrl\";s:41:\"http://ems.119next.com/media/public/.tmb/\";s:8:\"disabled\";a:1:{i:0;s:5:\"chmod\";}s:9:\"separator\";s:1:\"/\";s:13:\"copyOverwrite\";i:1;s:15:\"uploadOverwrite\";i:1;s:13:\"uploadMaxSize\";i:10485760;s:13:\"uploadMaxConn\";i:3;s:10:\"uploadMime\";a:3:{s:10:\"firstOrder\";s:4:\"deny\";s:5:\"allow\";a:2:{i:0;s:5:\"image\";i:1;s:5:\"video\";}s:4:\"deny\";a:14:{i:0;s:23:\"application/x-httpd-php\";i:1;s:15:\"application/php\";i:2;s:17:\"application/x-php\";i:3;s:8:\"text/php\";i:4;s:10:\"text/x-php\";i:5;s:30:\"application/x-httpd-php-source\";i:6;s:16:\"application/perl\";i:7;s:18:\"application/x-perl\";i:8;s:20:\"application/x-python\";i:9;s:18:\"application/python\";i:10;s:29:\"application/x-bytecode.python\";i:11;s:29:\"application/x-python-bytecode\";i:12;s:25:\"application/x-python-code\";i:13;s:18:\"wwwserver/shellcgi\";}}s:15:\"dispInlineRegex\";s:110:\"^(?:(?:video|audio)|image/(?!.+\\+xml)|application/(?:ogg|x-mpegURL|dash\\+xml)|(?:text/plain|application/pdf)$)\";s:10:\"jpgQuality\";i:100;s:9:\"archivers\";a:3:{s:6:\"create\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:7:\"extract\";a:5:{i:0;s:17:\"application/x-tar\";i:1;s:18:\"application/x-gzip\";i:2;s:19:\"application/x-bzip2\";i:3;s:16:\"application/x-xz\";i:4;s:15:\"application/zip\";}s:9:\"createext\";a:5:{s:17:\"application/x-tar\";s:3:\"tar\";s:18:\"application/x-gzip\";s:3:\"tgz\";s:19:\"application/x-bzip2\";s:3:\"tbz\";s:16:\"application/x-xz\";s:2:\"xz\";s:15:\"application/zip\";s:3:\"zip\";}}s:8:\"uiCmdMap\";a:0:{}s:11:\"syncChkAsTs\";i:1;s:9:\"syncMinMs\";i:10000;s:14:\"i18nFolderName\";i:0;s:7:\"tmbCrop\";i:1;s:13:\"substituteImg\";b:1;s:10:\"onetimeUrl\";b:0;s:6:\"csscls\";s:26:\"elfinder-navbar-root-local\";}s:8:\"volumeid\";s:3:\"l2_\";s:6:\"locked\";i:1;s:6:\"isroot\";i:1;s:5:\"phash\";s:0:\"\";}}s:7:\"subdirs\";a:1:{s:54:\"/usr/www/users/nextcwdmtm/ems.119next.com/media/public\";b:0;}}s:14:\":LAST_ACTIVITY\";i:1568748064;}elFinderNetVolumes|a:0:{}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f7b36a037287510f5efd051748e323cc8afbd09b', '207.241.229.160', 1568730917, '__ci_last_regenerate|i:1568730917;red_url|s:23:\"http://ems.119next.com/\";');


#
# TABLE STRUCTURE FOR: tblshared_customer_files
#

DROP TABLE IF EXISTS `tblshared_customer_files`;

CREATE TABLE `tblshared_customer_files` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblspam_filters
#

DROP TABLE IF EXISTS `tblspam_filters`;

CREATE TABLE `tblspam_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `rel_type` varchar(10) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstaff
#

DROP TABLE IF EXISTS `tblstaff`;

CREATE TABLE `tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` mediumtext,
  `linkedin` mediumtext,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(191) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT '0',
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `two_factor_auth_enabled` tinyint(1) DEFAULT '0',
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` text,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`) VALUES (1, 'norman@119next.com', 'Norman', 'Naidoo', '', '', '', '', '$2a$08$S.9.Gf90jFyxEpH7AFJHyecVJ15cHFcNZLdPFdbDlvLpJ0CoKEvle', '2019-09-17 16:16:39', 'small_small_norman.jpg', '105.228.160.195', '2019-09-17 16:18:38', '2019-09-17 21:55:22', NULL, NULL, NULL, 1, NULL, 1, '', '', NULL, 0, '0.00', 0, NULL, NULL, '');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`) VALUES (2, 'clint@call-lab.co.za', 'Clint', 'Brink', '', '', '', '', '$2a$08$jZ3QBVqokLRxjhcQwMV2B.K9nJEVy3Ww0oTOrrL5jKWiU7w4tUcAy', '2019-09-17 17:01:41', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, '', '', 'clint-brink', 0, '0.00', 0, NULL, NULL, '');


#
# TABLE STRUCTURE FOR: tblstaff_departments
#

DROP TABLE IF EXISTS `tblstaff_departments`;

CREATE TABLE `tblstaff_departments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstaff_permissions
#

DROP TABLE IF EXISTS `tblstaff_permissions`;

CREATE TABLE `tblstaff_permissions` (
  `staff_id` int(11) NOT NULL,
  `feature` varchar(40) NOT NULL,
  `capability` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsubscriptions
#

DROP TABLE IF EXISTS `tblsubscriptions`;

CREATE TABLE `tblsubscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text,
  `description_in_item` tinyint(1) NOT NULL DEFAULT '0',
  `clientid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `terms` text,
  `currency` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT '0',
  `stripe_tax_id` varchar(50) DEFAULT NULL,
  `stripe_plan_id` text,
  `stripe_subscription_id` text NOT NULL,
  `next_billing_cycle` bigint(20) DEFAULT NULL,
  `ends_at` bigint(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `hash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int(11) NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveyresultsets
#

DROP TABLE IF EXISTS `tblsurveyresultsets`;

CREATE TABLE `tblsurveyresultsets` (
  `resultsetid` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `useragent` varchar(150) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`resultsetid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveys
#

DROP TABLE IF EXISTS `tblsurveys`;

CREATE TABLE `tblsurveys` (
  `surveyid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext NOT NULL,
  `slug` mediumtext NOT NULL,
  `description` text NOT NULL,
  `viewdescription` text,
  `datecreated` datetime NOT NULL,
  `redirect_url` varchar(100) DEFAULT NULL,
  `send` tinyint(1) NOT NULL DEFAULT '0',
  `onlyforloggedin` int(11) DEFAULT '0',
  `fromname` varchar(100) DEFAULT NULL,
  `iprestrict` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `hash` varchar(32) NOT NULL,
  PRIMARY KEY (`surveyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveysemailsendcron
#

DROP TABLE IF EXISTS `tblsurveysemailsendcron`;

CREATE TABLE `tblsurveysemailsendcron` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailid` int(11) DEFAULT NULL,
  `listid` varchar(11) DEFAULT NULL,
  `log_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblsurveysendlog
#

DROP TABLE IF EXISTS `tblsurveysendlog`;

CREATE TABLE `tblsurveysendlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `surveyid` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `iscronfinished` int(11) NOT NULL DEFAULT '0',
  `send_to_mail_lists` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaggables
#

DROP TABLE IF EXISTS `tbltaggables`;

CREATE TABLE `tbltaggables` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT '0',
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltags
#

DROP TABLE IF EXISTS `tbltags`;

CREATE TABLE `tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tbltags` (`id`, `name`) VALUES (2, 'Norman Naidoo');
INSERT INTO `tbltags` (`id`, `name`) VALUES (1, 'Test');


#
# TABLE STRUCTURE FOR: tbltask_assigned
#

DROP TABLE IF EXISTS `tbltask_assigned`;

CREATE TABLE `tbltask_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT '0',
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltask_checklist_items
#

DROP TABLE IF EXISTS `tbltask_checklist_items`;

CREATE TABLE `tbltask_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` text NOT NULL,
  `finished` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT '0',
  `list_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltask_comments
#

DROP TABLE IF EXISTS `tbltask_comments`;

CREATE TABLE `tbltask_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT '0',
  `file_id` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltask_followers
#

DROP TABLE IF EXISTS `tbltask_followers`;

CREATE TABLE `tbltask_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltasks
#

DROP TABLE IF EXISTS `tbltasks`;

CREATE TABLE `tbltasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext,
  `description` text,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT '0',
  `is_recurring_from` int(11) DEFAULT NULL,
  `cycles` int(11) NOT NULL DEFAULT '0',
  `total_cycles` int(11) NOT NULL DEFAULT '0',
  `custom_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `billable` tinyint(1) NOT NULL DEFAULT '0',
  `billed` tinyint(1) NOT NULL DEFAULT '0',
  `invoice_id` int(11) NOT NULL DEFAULT '0',
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `milestone` int(11) DEFAULT '0',
  `kanban_order` int(11) NOT NULL DEFAULT '0',
  `milestone_order` int(11) NOT NULL DEFAULT '0',
  `visible_to_client` tinyint(1) NOT NULL DEFAULT '0',
  `deadline_notified` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltasks_checklist_templates
#

DROP TABLE IF EXISTS `tbltasks_checklist_templates`;

CREATE TABLE `tbltasks_checklist_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaskstimers
#

DROP TABLE IF EXISTS `tbltaskstimers`;

CREATE TABLE `tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `note` text,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaxes
#

DROP TABLE IF EXISTS `tbltaxes`;

CREATE TABLE `tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbltaxes` (`id`, `name`, `taxrate`) VALUES (1, 'ZAR', '15.00');


#
# TABLE STRUCTURE FOR: tblticket_attachments
#

DROP TABLE IF EXISTS `tblticket_attachments`;

CREATE TABLE `tblticket_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticket_replies
#

DROP TABLE IF EXISTS `tblticket_replies`;

CREATE TABLE `tblticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT '0',
  `name` text,
  `email` text,
  `date` datetime NOT NULL,
  `message` text,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltickets
#

DROP TABLE IF EXISTS `tbltickets`;

CREATE TABLE `tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT '0',
  `email` text,
  `name` text,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` text,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT '0',
  `adminread` int(11) NOT NULL DEFAULT '0',
  `assigned` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltickets_pipe_log
#

DROP TABLE IF EXISTS `tbltickets_pipe_log`;

CREATE TABLE `tbltickets_pipe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` mediumtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltickets_predefined_replies
#

DROP TABLE IF EXISTS `tbltickets_predefined_replies`;

CREATE TABLE `tbltickets_predefined_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbltickets_predefined_replies` (`id`, `name`, `message`) VALUES (1, 'Thank you for contacting support', '<span><img src=\"http://ems.119next.com/media/d.jpeg\" alt=\"Syntell\" width=\"200\" height=\"200\" /><br />Thanks for contacting our Support team.</span><br /><br /><span>We have received your mail and one of our consultants will reply to you shortly to assist with your query - typically within 2 hours. Technical support is offered 24/7/365.</span><br /><br /><span>If your query is urgent, please contact us telephonically</span><br /><span>on 0861 xxx xxx.</span>');


#
# TABLE STRUCTURE FOR: tbltickets_priorities
#

DROP TABLE IF EXISTS `tbltickets_priorities`;

CREATE TABLE `tbltickets_priorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (1, 'Low');
INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (2, 'Medium');
INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (3, 'High');


#
# TABLE STRUCTURE FOR: tbltickets_status
#

DROP TABLE IF EXISTS `tbltickets_status`;

CREATE TABLE `tbltickets_status` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT '0',
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (1, 'Open', 1, '#ff2d42', 1);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (2, 'In progress', 1, '#84c529', 2);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (3, 'Answered', 1, '#0000ff', 3);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (4, 'On Hold', 1, '#c0c0c0', 4);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (5, 'Closed', 1, '#03a9f4', 5);


#
# TABLE STRUCTURE FOR: tbltodos
#

DROP TABLE IF EXISTS `tbltodos`;

CREATE TABLE `tbltodos` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltracked_mails
#

DROP TABLE IF EXISTS `tbltracked_mails`;

CREATE TABLE `tbltracked_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT '0',
  `date_opened` datetime DEFAULT NULL,
  `subject` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbluser_auto_login
#

DROP TABLE IF EXISTS `tbluser_auto_login`;

CREATE TABLE `tbluser_auto_login` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbluser_meta
#

DROP TABLE IF EXISTS `tbluser_meta`;

CREATE TABLE `tbluser_meta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `client_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(191) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('1', '1', '0', '0', 'dashboard_widgets_visibility', 'a:9:{i:0;a:2:{s:2:\"id\";s:9:\"top_stats\";s:7:\"visible\";s:1:\"1\";}i:1;a:2:{s:2:\"id\";s:16:\"finance_overview\";s:7:\"visible\";s:1:\"1\";}i:2;a:2:{s:2:\"id\";s:9:\"user_data\";s:7:\"visible\";s:1:\"1\";}i:3;a:2:{s:2:\"id\";s:8:\"calendar\";s:7:\"visible\";s:1:\"1\";}i:4;a:2:{s:2:\"id\";s:21:\"weekly_payments_chart\";s:7:\"visible\";s:1:\"1\";}i:5;a:2:{s:2:\"id\";s:5:\"todos\";s:7:\"visible\";s:1:\"1\";}i:6;a:2:{s:2:\"id\";s:11:\"leads_chart\";s:7:\"visible\";s:1:\"1\";}i:7;a:2:{s:2:\"id\";s:14:\"projects_chart\";s:7:\"visible\";s:1:\"1\";}i:8;a:2:{s:2:\"id\";s:17:\"projects_activity\";s:7:\"visible\";s:1:\"1\";}}');


#
# TABLE STRUCTURE FOR: tblvault
#

DROP TABLE IF EXISTS `tblvault`;

CREATE TABLE `tblvault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_address` varchar(191) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `password` text NOT NULL,
  `description` text,
  `creator` int(11) NOT NULL,
  `creator_name` varchar(100) DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT '1',
  `share_in_projects` tinyint(1) NOT NULL DEFAULT '0',
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblviews_tracking
#

DROP TABLE IF EXISTS `tblviews_tracking`;

CREATE TABLE `tblviews_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblweb_to_lead
#

DROP TABLE IF EXISTS `tblweb_to_lead`;

CREATE TABLE `tblweb_to_lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT '1',
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext,
  `responsible` int(11) NOT NULL DEFAULT '0',
  `name` varchar(191) NOT NULL,
  `form_data` mediumtext,
  `recaptcha` int(11) NOT NULL DEFAULT '0',
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `success_submit_msg` text,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT '1',
  `mark_public` int(11) NOT NULL DEFAULT '0',
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT '0',
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

